#- tabla chula con inflación OCDE ----------------------------------------------
#- con dygraph: https://rstudio.github.io/dygraphs/index.html
library(tidyverse)
library(gt)


#- Datos -----------------------------------------------------------------------
#- Inflación de la OCDE -
#- web: https://data.oecd.org/price/inflation-cpi.htm
url_inflation <- "https://stats.oecd.org/sdmx-json/data/DP_LIVE/.CPI.../OECD?contentType=csv&detail=code&separator=comma&csv-lang=en"
ruta_inflation <- "./datos/ocde/DP_LIVE_22032023113248591.csv"
# curl::curl_download(url_inflation, ruta_inflation)
# download.file(url_inflation, ruta_inflation)
inflation_orig <- readr::read_csv(ruta_inflation)
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inflation_orig)
inflation_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(inflation_orig)

#- data munging
inflation <- inflation_orig %>%
  dplyr::filter(FREQUENCY == "M") %>%
  dplyr::filter(MEASURE == "AGRWTH") %>%
    dplyr::filter(SUBJECT %in% c("TOT", "ENRG")) %>%
  select(pais = LOCATION, date = TIME, cpi = Value, subject = SUBJECT)

inflation <- inflation %>% pivot_wider(names_from = subject, values_from = cpi)




#- un solo país
inf_esp <- inflation %>%
  filter(pais == "ESP")
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inf_esp)



# Library
library(dygraphs)
library(xts)          # To make the convertion data-frame / xts format
library(lubridate)

#data <- read.table("https://raw.githubusercontent.com/holtzy/data_to_viz/master/Example_dataset/3_TwoNumOrdered.csv", header=T)

#- pasamos date a fecha
df <- inf_esp %>% mutate(fecha = lubridate::ym(date))
df <- df %>% select(fecha, TOT, ENRG)

df_dygraph <- xts(x = df$TOT , order.by = df$fecha)




presAnnotation <- function(dygraph, x, text) {
  dygraph %>%
    dyAnnotation(x, text, attachAtBottom = F, width = 60)
}


# Finally the plot
p <- dygraph(df_dygraph,
main = "Tasa de inflación interanual (España, datos mensuales, OCDE)",
ylab = "Tasa de inflación (%)") %>%
  dySeries("V1", label = "Tasa Inf. interanual") %>%
  dyLegend(show = "always", hideOnMouseOut = FALSE) %>%
  dyOptions(labelsUTC = TRUE, fillGraph=TRUE, fillAlpha=0.13, drawGrid = FALSE, colors="black") %>%
  dyRangeSelector() %>%
  dyCrosshair(direction = "vertical") %>%
  dyHighlight(highlightCircleSize = 5, highlightSeriesBackgroundAlpha = 0.2, hideOnMouseOut = FALSE)  %>%
  dyRoller(rollPeriod = 1) %>%
  presAnnotation("1977-08-01", text = "28,43%") %>%
  presAnnotation("2009-07-01", text = "-1,37%") %>%
  presAnnotation("2008-07-01", text = "Crisis financiera global") %>%
  dyShading(from = "1955-03-01",to="1970-01-01",color = "#b2d8d8") %>%
  dyShading(from = "1970-01-01", to = "1990-01-01", color = "#CCEBD6") %>%
  dyShading(from = "1990-01-01", to = "2010-01-01", color = "#b2d8d8") %>%
  dyShading(from = "2010-01-01", to = "2017-10-01", color = "#CCEBD6") %>%
  dyShading(from = "2017-11-12", to = "2018-02-01", color = "#b2d8d8") %>%
  dyShading(from = "2008-03-01", to = "2013-10-01", color = "#dfe3ee") %>%
  dyShading(from = "2013-10-01", to = "2023-02-11", color = "#b2d8d8") %>%
  dyEvent("1973-10-01", "Primera crisis del petroleo (oct-73)", labelLoc = "bottom") %>%
  dyEvent("1978-01-01", "Segunda crisis del petroleo", labelLoc = "bottom") %>%
  dyEvent("1986-07-01", "España entra en la UE", labelLoc = "bottom") %>%
  dyEvent("1992-02-01", "Firma del tratado de Maastricth por España", labelLoc = "bottom") %>%
  dyEvent("1999-01-01", "Euro en vigor", labelLoc = "bottom") %>%
  dyEvent("2014-03-18", "Rusia se anexiona Crimea", labelLoc = "bottom") %>%
  dyEvent("2016-06-23", "Reino Unido aprueba la salida de EU", labelLoc = "bottom") %>%
  dyEvent("2017-01-20", "Donald Trump es presidente", labelLoc = "bottom") %>%
  dyEvent("2020-03-01", "Inicio pandemia Covid", labelLoc = "bottom") %>%
  dyEvent("2022-02-24", "Rusia invade Ucrania", labelLoc = "bottom")

p


