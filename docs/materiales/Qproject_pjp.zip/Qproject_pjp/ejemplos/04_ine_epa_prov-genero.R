#- ejemplo con datos INE (EPA)
#- Ultimos datos EPA:  https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=ultiDatos&idp=1254735976595
#- Hay muchas tablas. anuales, trimestrales, CCAA, provinciales etc ... etc ...

library(tidyverse)

#- grupo de Sonia Monleón 
#- Tasas de actividad, paro y empleo por PROVINCIA y sexo: https://www.ine.es/jaxiT3/Tabla.htm?t=3996&L=0


#- Descargamos la tabla del INE
# my_url <- "https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/3996.csv?nocab=1"
# curl::curl_download(my_url, "./datos/epa_prov-genero.csv")

#- DETALLE: los datos q hemos descargados están en formato "csv" (PERO separados por ;)
#- Importamos la tabla al Global
df <- rio::import("./datos/epa_prov-genero.csv") #- no los interpreta bien
str(df)



#- antes de hacer nada: los nombres de las variables tienen q estar bien (ser sintácticamente válidos)
names(df) #- están bien pero ... aún así quiero recordar janitor::clean_names()
df <- janitor::clean_names(df) 
names(df)

#- Pb con la tasa de paro (en la v. total) tiene "," en el decimal
df <- df %>% mutate(total = stringr::str_replace(total, "," , "." ))
str(df)
df <- df %>% mutate(total = as.numeric(total)) #- hay un pb en el ultimo dato de Melilla
zz <- df %>% filter(is.na(total)) #- solo para ver cuantos NA's se han creado

#- Veamos q hay en df ----------------------------------------------------
df_dicc <- pjpv.curso.R.2022::pjp_dicc(df)
df_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(df)

rm(df_dicc, df_uniques)


#- antes de empezar hay que separar 2 columnas
#- 1) la v. fecha está como texto ("2022T3") la pasamos a fecha y sacamos año y cuatrimestre
df <- df %>% 
  mutate(fecha = lubridate::yq(periodo)) %>% 
  mutate(anyo = lubridate::year(fecha)) %>% 
  #mutate(mes = lubridate::month(fecha)) %>% #- el mes no tiene sentido (son trimestrales)
  mutate(trimestre = lubridate::quarter(fecha))  %>% 
  select(-periodo)   #- quito lo q no hace falta

head(df)

#- 2) La v "provincias" tiene el código y el nombre
# ademas, en provincias estan las 52 prov y el "Total nacional"
#- arreglarlo (ponerlo similar a las provincias)
df <- df %>% 
  mutate(provincias = ifelse(provincias == "Total Nacional",
                             paste("00", provincias),
                             provincias))
#- para luego separalos
df <- df %>%  
  tidyr::separate(provincias, sep = " ", 
                  into = c("ine_prov", "ine_prov.n"), extra = "merge") 
head(df)
#- veamos que tasas hay
df_wide <- df %>% pivot_wider(names_from = tasas, values_from = total) 

df_wide <- janitor::clean_names(df_wide)
names(df_wide)
df_wide <- df_wide %>% 
  rename(tasa_actividad = tasa_de_actividad) %>% 
  rename(tasa_paro = tasa_de_paro_de_la_poblacion) %>% 
  rename(tasa_empleo = tasa_de_empleo_de_la_poblacion) 

df_wide <- df_wide %>% 
       rename(ine_prov.n = ine_prov_n)  

df_orig <- df_wide    #- AQUI
  
#- PREGUNTAS q podemos hacer:
#- 0) Evolución en el tiempo
#- 1) estacionalidad 
#- 3) comparación provincial


#
#- simplemente voy a hacer un barplot 
#- por ejemplo en 2022 T2

df_p <- df_wide %>% 
  filter(anyo == 2022) %>% 
  filter(trimestre == 3) %>% 
  filter(sexo == "Ambos sexos")

p1 <- ggplot(df_p, aes(y = ine_prov.n, x = tasa_actividad)) + geom_col()
p1

#- reordenamos

df_p <- df_p %>% mutate(ine_prov.n.f = as.factor(ine_prov.n))
df_p <- df_p %>% mutate(ine_prov.n.f = forcats::fct_reorder(ine_prov.n.f, tasa_actividad))

                        
p1 <- ggplot(df_p, aes(y = ine_prov.n.f, x = tasa_actividad)) + geom_col()
p1

#- Opciones --------------------------------------------------------------------
#- para mejorar el barplot: https://albert-rapp.de/posts/ggplot2-tips/16_bars_checklist/16_bars_checklist.html        
#- BUMP-plot: https://dominikkoch.github.io/Bump-Chart/

#- Bar race

#- dejo solo datos del primer trimestre y de sexo == "Ambos sexos"
df_x <- df_wide %>% filter(trimestre == 1) %>% 
  group_by(anyo, sexo) %>% 
  mutate(ine_prov.n.f = as.factor(ine_prov.n)) %>% 
  mutate(ine_prov.n.f = forcats::fct_reorder(ine_prov.n.f, tasa_actividad)) %>% 
  ungroup() %>% 
  filter(sexo == "Ambos sexos") 

#- solo 
df_xx <- df_x %>%
  filter(ine_prov %in% c ("01", "02", "03", "04", "05"))

p1 <- ggplot(df_xx, aes(y = ine_prov.n.f, x = tasa_paro)) + geom_col()
p1 + facet_wrap(vars(anyo))

#- bar race con pkg ddplot ----
#- https://www.infoworld.com/article/3633448/easy-racing-bar-charts-in-r-with-ddplot.html
# remotes::install_github("feddelegrand7/ddplot", build_vignettes = TRUE)
library(ddplot)

barChartRace(
  data = df_xx, # data frame
  y = "ine_prov", # name of x axis column as string
  x = "tasa_paro", # name of y axis column as string
  time = "anyo", #name of time variable column as strong
  colorCategory = "Accent", # 1 of 10 available D3 named categorical color palettes
  sort = "descending"# 'none', 'ascending', 'descending'
)



#- pkg echarts4 ---------
#- https://www.infoworld.com/article/3607068/plot-in-r-with-echarts4r.html
df_xx %>% 
  group_by(anyo) %>% #<<
  e_charts(ine_prov.n, timeline = TRUE) %>% #<<
  e_timeline_opts(autoPlay = TRUE, top = 40) %>% #<<
  e_bar(tasa_paro, itemStyle = list(color = "#0072B2"))  %>% 
  e_legend(show = FALSE) %>% 
  e_labels(position = 'insideTop') %>%
  e_title("Percent Received Covid-19 Vaccine Doses Administered", 
          left = "center", top = 5, 
          textStyle = list(fontSize = 24)) %>%
  e_grid(top = 100)


#- bar race con pkg gganimate ---------
df_xx <- df_x %>%
  filter(ine_prov %in% c ("01", "02", "03", "04", "05"))

p1 <- ggplot(df_xx, aes(y = ine_prov.n.f, x = tasa_paro)) + geom_col()
p1 + facet_wrap(vars(anyo))


library(gganimate)
p1 +
  ggtitle('{closest_state}') +                  # Titulo == al valor de la columna que
  transition_states(anyo,                       # Animamos la columna Year
                    transition_length = 1,      # Duración de la animación de transición
                    state_length = 1) +         # Duración de cada Year
  exit_fly(x_loc = 0, y_loc = 0) +              # Salida de la ciudad no top4
  enter_fly(x_loc = 0, y_loc = 0)      



#- bar race con pkg robservable
#- https://juba.github.io/robservable/articles/gallery.html
df_xx <- df_x %>%
  filter(ine_prov %in% c ("01", "02", "03", "04", "05"))

p1 <- ggplot(df_xx, aes(y = ine_prov.n.f, x = tasa_paro)) + geom_col()
p1 + facet_wrap(vars(anyo))


#- https://juba.github.io/robservable/articles/gallery.html
#remotes::install_github("juba/robservable")

library(robservable)
df_observable <- df_xx %>% 
  mutate(id = ine_prov.n) %>% 
  mutate(date = anyo) %>% 
  mutate(value = tasa_paro)
  
  
robservable(
  "https://observablehq.com/@juba/bar-chart-race",
  include = c("viewof date", "chart", "draw", "styles"),
  hide = "draw",
  input = list(
    data = df_observable,
    title = "COVID-19 deaths",
    subtitle = "Cumulative number of COVID-19 deaths by country",
    source = "Source : Johns Hopkins University"
  ),
  width = 700,
  height = 710
)
