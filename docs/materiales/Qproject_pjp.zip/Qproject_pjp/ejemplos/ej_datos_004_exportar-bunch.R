#- vamos a ver como podríamos importar varios archivos de datos en una misma carpeta
#- No es fácil!!
#- Un post: https://kieranhealy.org/blog/archives/2023/03/25/reading-remote-data-files/  aunque uso map_dfr() que en purrr 1.0.0 ha quedado superseded: https://fosstodon.org/@johnmackintosh/109768966119899585

library(tidyverse)

#- Para ello, primero vamos a crear varios conjuntos de datos
#- primero creamos solo un fdf con assign(). Esto no es fácil-fácil
assign(paste0("iris_", "01"), iris)
rm("iris_01")

 #- ok, ahora vamos a crear 3 ficheros de datos con la misma estructura
 #- esto no es fácil-fácil
anyos <- c(2021:2023)
my_names <- vector()

 for (ii in 1:length(anyos)) {
   print(anyos[ii])
   my_names[ii] <- paste0("iris_", anyos[ii])
   assign(my_names[ii], iris)
 }

#- OK, tenemos 3 df's q queremos exportar
#- esto no es fácil-fácil
get("iris_2021")

fs::dir_create("./pruebas") #- creo la carpeta

for (ii in 1:length(my_names)) {
  my_name <- my_names[ii]
  my_df <- get(my_name)
  my_ruta <- paste0("./pruebas/", my_name, ".csv")
  print(my_ruta)
  rio::export(my_df, my_ruta)
}

rm(my_df)
rm(list = ls())

#- OK, ya tenemos 3 archivos de datos (.csv) q queremos importar
#- AQUI en realidad empezaría el ejercicio de importación de un conjunto de archivos con datos

my_carpeta <- here::here("pruebas") #- la carpeta donde están los archivos q quiero importar

#- cojo las rutas a los archivos
mys_rutas <- list.files(my_carpeta)   #- Ok con base ...
mys_rutas <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"
mys_rutas

#- genero nombres para los df's donde se almacenarán los datos de los archivos
mis_nombres <- paste0("iris_imp_", 2021:2023)

for (ii in 1:length(mys_rutas)) {
  assign(mis_nombres[ii], rio::import(mys_rutas[ii]))
}


#- con purrr es easy, PERO hay que saber un poco sobre manipular listas
my_dfs_list <- purrr::map(mys_rutas, rio::import)

#- 2 posibilidades para combinarlas
tbl.0 <- my_dfs_list %>% purrr::reduce(bind_rows)
tbl.0 <- bind_rows(my_dfs_list, .id = "id")


#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#- MÁS PRO
#- esto sería lo (casí) feten
tbl.1 <- fs::dir_ls("pruebas", regexp = "[.]csv$") %>%
       purrr::map_dfr(readr::read_csv, .id = "id")



#- más intuitivo podría ser algo así:
rutas_a_files <-  fs::dir_ls("pruebas", regexp = "[.]csv$") #-vector con las rutas a los archivos .csv


tbl.2 <- rio::import("./pruebas/iris_2021.csv") %>% #- cargo uno de los .csv's
  mutate(id = 1, .before = 1) %>%   #- genero una v. q marque el df de procedencia de los datos
  slice(0)                          #- dejo el data.frame vacio

#- loop para cargar los ficheros y fusionarlos
for (ii in 1:length(rutas_a_files)){
  tmp <- rio::import(rutas_a_files[ii]) %>% mutate(id = ii, .before = 1)
  tbl.2 <- bind_rows(tbl.2, tmp)
}

rm(tmp)
