#- plot temporales inflación OCDE ----------------------------------------------
#- https://twitter.com/leeolney3/status/1510564709740826625
#- https://twitter.com/braeuNERD/status/1510690816645287947
#- https://twitter.com/malasi_abhinav/status/1514143026297323524
#- https://twitter.com/BolesData/status/1518297682984452097/photo/1
#- https://twitter.com/FrederikRasmus9/status/1520821825034506242
#- plot de Lorena: https://github.com/loreabad6/TidyTuesday/blob/master/plot/2020_week_38.png
#- repo: https://github.com/loreabad6/TidyTuesday/blob/master/R/2020/week_39.Rmd
#- plot: https://github.com/Pecners/tidytuesday/blob/master/2022/2022-03-22/final_plot.png
#- repo: https://github.com/Pecners/tidytuesday/blob/master/2022/2022-03-22/final_plot.R

library(tidyverse)
library(gt)


#- Datos -----------------------------------------------------------------------
#- Inflación de la OCDE -
#- web: https://data.oecd.org/price/inflation-cpi.htm
url_inflation <- "https://stats.oecd.org/sdmx-json/data/DP_LIVE/.CPI.../OECD?contentType=csv&detail=code&separator=comma&csv-lang=en"
ruta_inflation <- "./pruebas/DP_LIVE_22032023113248591.csv"
# curl::curl_download(url_inflation, ruta_inflation)
# download.file(url_inflation, ruta_inflation)
inflation_orig <- readr::read_csv(ruta_inflation)
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inflation_orig)
inflation_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(inflation_orig)

#- data munging
inflation <- inflation_orig %>%
  dplyr::filter(FREQUENCY == "M") %>% 
  dplyr::filter(MEASURE == "AGRWTH") %>% 
  #dplyr::filter(SUBJECT %in% c("TOT", "ENRG")) %>%
  dplyr::mutate(fecha = lubridate::ym(TIME)) %>% 
  select(pais = LOCATION, fecha, inflacion = Value, tipo_inf = SUBJECT)

#inflation <- inflation %>% pivot_wider(names_from = subject, values_from = cpi)
#pivot_longer(cols = ENRG:TOT, names_to = "indicador", values_to = "inflacion") %>% 



#- incorporar region para filtrar grupos de países
zz <- countrycode::codelist %>% select(iso.name.en, region, region23, wb, fips, ioc, imf, iso2c, iso3c, ecb, eurostat, continent, eu28, un, un.region.name)
#zz <- countrycode::codelist %>% select(iso.name.en, region23, region, iso3c) 

inflation <- left_join(inflation, zz, by = join_by(pais == iso3c) ) # %>% distinct(pais, .keep_all = TRUE)



#- PLOTS -----------------------------------------------------------------------
library(ggtext) # package to interpret HTML with element_markdown to color titles
library(showtext) # for specific fonts; font_add_google
library(glue)

# Fuentes y opciones
font_add_google("Fira Sans Condensed")
showtext_opts(dpi = 300)
showtext_auto(enable = TRUE)


#- plot 1 ----------------------------------------------------------------------
#- https://twitter.com/leeolney3/status/1510564709740826625
#- gist: https://gist.github.com/leeolney3/50e0a8e2444c3a51f4cfb5ee1aa664c0

#- solo Europa (q no sea Europa del Este) desde 2020
my_fecha <-  "2020-01-01"

df <- inflation %>% 
  dplyr::filter(un.region.name %in% c("Europe")) %>% 
  dplyr::filter(!(region23 %in% c("Eastern Europe")))  %>% 
  dplyr::filter(fecha >= my_fecha) %>% 
  dplyr::filter(tipo_inf %in% c("TOT", "TOT_FOODENRG"))


df_dicc <- pjpv.curso.R.2022::pjp_dicc(df)

my_title = "Evolución (mensual) de la **tasa de inflación interanual**. Enero 2020 - Marzo 2023"
my_subtitle <- "<span style='color:#229F99'> Inflación total </span> e <span style='color:#D17011'> Inflación sin alimentos ni energía </span>"


p1 <- df %>% ggplot() +
  geom_line(aes(x = fecha, y = inflacion, color = tipo_inf, group = tipo_inf)) +
  geom_point(aes(x = fecha, y = inflacion, color = tipo_inf, group = tipo_inf), size = .8) +
  scale_color_manual(values = c("#229F99", "#D17011", "#777000", "#E37099")) +
  scale_y_continuous(limits = c(-7, 25), labels = scales::percent_format(scale = 1, accuracy = 1)) +
  facet_wrap(~ factor(pais)) +
  theme_minimal() +
  theme(legend.position = "none",
        text = element_text(family = "Fira Sans Condensed"),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(size=.3),
        plot.margin = margin(.5,.75,.5,.5, unit="cm"),
        plot.title.position = "plot",
        plot.title = element_markdown(size= 10),
        panel.spacing.x = unit(1.5, "lines"),
        strip.text = element_markdown(lineheight = 1.2, size = 7.5),
        plot.subtitle = element_markdown(size = 9, lineheight = 1.2, color = "grey20"),
        plot.caption = element_text(color="grey20"),
        axis.title = element_blank()) +
  labs(title = my_title, subtitle= my_subtitle,
       caption = "\n Pedro J. Pérez  |  Data source: data.oecd.org")

p1

#- plot 2 ----------------------------------------------------------------------
#- https://twitter.com/braeuNERD/status/1510690816645287947
#- repo: https://github.com/BraeuNerd/30DayChartChallenge2022/blob/main/Scripts/W1D3_Historical.R

# Fuentes
font_add_google("Roboto")
showtext_auto()

#- solo Europa (q no sea Europa del Este) desde 2020
my_fecha <-  "2020-01-01"

df <- inflation %>% 
  dplyr::filter(un.region.name %in% c("Europe")) %>% 
  dplyr::filter(!(region23 %in% c("Eastern Europe")))  %>% 
  dplyr::filter(fecha >= my_fecha) %>% 
  dplyr::filter(tipo_inf == "TOT") %>% 
  mutate(pais.2 = pais)  #- para resaltar 1 pais

my_title <- "Evolución (mes a mes) de la tasa de inflación interanual (enero 2020, marzo 2023)"
my_subtitle <- "Países europeos"


p2 <- 
  ggplot(df, aes(x = fecha, y = inflacion)) +
    geom_line(data = df %>% select(-pais), 
              aes(group = pais.2), color = "white", linewidth = 0.3, alpha = 0.3) +
    geom_line(aes(color = pais, group = pais), color = "#FED459", linewidth = 1) +
    geom_point(aes(color = pais, group = pais), color = "#FED459", size = 1.2) +
    theme(legend.position = "none") +
    facet_wrap(~ pais) +
  #scale_x_discrete(breaks = seq(2020:01,2023:03, by=2)) +
  labs(title = my_title, subtitle = my_subtitle,
       caption = "Datos de la OCDE |   DataViz: Pedro J. Pérez") +
  theme(plot.background = element_rect(fill = "#171717", color = "#171717"),
        panel.background = element_rect(fill = "#171717"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_markdown(family = "Roboto",color = "white", size = 11, margin = margin(20,0,0,0)),
        plot.subtitle = element_markdown(family = "Roboto", color = "white", size = 10, margin = margin(5,0,10,0)),
        plot.caption = element_text(family = "Roboto", hjust = 0.95, color = "grey70", size = 7, margin = margin(0,0,20,0)),
        axis.title.x = element_blank(),
        axis.text.x = element_text(color = "grey70", size = 3, margin = margin(0,20,20,0), angle = 90),
        axis.text.y = element_text(color = "grey70", size = 3),
        axis.title.y = element_blank(),
        strip.background = element_rect(fill = "#171717"),
        strip.text.x = element_text(color = "white"))

p2


#- plot 3 ----------------------------------------------------------------------


# Fuentes
font_add_google("Roboto")
showtext_auto()

#- solo Europa (q no sea Europa del Este) desde 2020
my_fecha <-  "2020-01-01"

df <- inflation %>% 
  dplyr::filter(un.region.name %in% c("Europe")) %>% 
  dplyr::filter(!(region23 %in% c("Eastern Europe")))  %>% 
  dplyr::filter(fecha >= my_fecha) 

my_title <- "Tasas de inflación interanual en Europa (enero 2020, marzo 2023)"
my_subtitle <- "Países europeos y <span style='color:#FED459'> España </span> "

p3
p3 <- 
  ggplot(df, aes(x = fecha, y = inflacion)) +
    geom_line(aes(group = pais), color = "white", linewidth = 0.3, alpha = 0.3) +
    geom_line(data = df %>% filter(pais == "ESP"), aes(color = pais, group = pais), color = "#FED459", linewidth = 1) +
    geom_point(data = df %>% filter(pais == "ESP"), aes(color = pais, group = pais), color = "#FED459", size = 1.2) +
    theme(legend.position = "none") +
    facet_wrap(vars(tipo_inf), nrow = 2, ncol = 2, scales = "free") +
  #scale_x_discrete(breaks = seq(2020:01,2023:03, by=2)) +
  labs(title = my_title, subtitle = my_subtitle,
       caption = "Datos de la OCDE |   DataViz: Pedro J. Pérez") +
  theme(plot.background = element_rect(fill = "#171717", color = "#171717"),
        panel.background = element_rect(fill = "#171717"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_markdown(family = "Roboto",color = "white", size = 11, margin = margin(20,0,0,0)),
        plot.subtitle = element_markdown(family = "Roboto", color = "white", size = 10, margin = margin(5,0,10,0)),
        plot.caption = element_text(family = "Roboto", hjust = 0.95, color = "grey70", size = 7, margin = margin(0,0,20,0)),
        axis.title.x = element_blank(),
        axis.text.x = element_text(color = "grey70", size = 6.4, margin = margin(0,20,20,0), angle = 90),
        axis.text.y = element_text(color = "grey70", size = 6.7),
        axis.title.y = element_blank(),
        strip.background = element_rect(fill = "#171717"),
        strip.text.x = element_text(color = "white"))

p3

#- un poco interactivo)
plotly::ggplotly(p3)
