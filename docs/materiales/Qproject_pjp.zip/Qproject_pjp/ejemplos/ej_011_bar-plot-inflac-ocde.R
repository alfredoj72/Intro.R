#- tabla inflación OCDE --------------------------------------------------------
#- https://twitter.com/camartinezbu/status/1517234323698683904
#- code: https://github.com/camartinezbu/30DayChartChallenge2022/blob/main/18-OECD/scripts/1-plot.R
#- https://schliebs.github.io/ggoxford/reference/geom_axis_flags.html
#- https://stackoverflow.com/questions/50380819/create-barplots-in-ggplot2-filled-with-flags-or-images
#- https://www.reddit.com/r/rstats/comments/7qv159/ggplot2_is_it_possible_to_set_country_flag_images/
#- https://github.com/jimjam-slam/ggflags
#- https://stackoverflow.com/questions/71721517/combine-ggflags-with-linear-regression-in-ggplot2


library(tidyverse)
library(gt)


#- Datos -----------------------------------------------------------------------
#- Inflación de la OCDE -
#- web: https://data.oecd.org/price/inflation-cpi.htm
url_inflation <- "https://stats.oecd.org/sdmx-json/data/DP_LIVE/.CPI.../OECD?contentType=csv&detail=code&separator=comma&csv-lang=en"
ruta_inflation <- "./pruebas/DP_LIVE_22032023113248591.csv"
# curl::curl_download(url_inflation, ruta_inflation)
# download.file(url_inflation, ruta_inflation)
inflation_orig <- readr::read_csv(ruta_inflation)
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inflation_orig)
inflation_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(inflation_orig)

#- data munging
inflation <- inflation_orig %>%
  dplyr::filter(FREQUENCY == "M") %>% 
  dplyr::filter(MEASURE == "AGRWTH") %>% 
  #dplyr::filter(SUBJECT %in% c("TOT", "ENRG")) %>%
  dplyr::mutate(fecha = lubridate::ym(TIME)) %>% 
  select(pais = LOCATION, fecha, inflacion = Value, tipo_inf = SUBJECT)

#inflation <- inflation %>% pivot_wider(names_from = subject, values_from = cpi)
#pivot_longer(cols = ENRG:TOT, names_to = "indicador", values_to = "inflacion") %>% 

#- incorporar region para filtrar grupos de países
zz <- countrycode::codelist %>% select(iso.name.en, region, region23, wb, fips, ioc, imf, iso2c, iso3c, ecb, eurostat, continent, eu28, un, un.region.name)
#zz <- countrycode::codelist %>% select(iso.name.en, region23, region, iso3c) 

inflation <- left_join(inflation, zz, by = join_by(pais == iso3c) ) # %>% distinct(pais, .keep_all = TRUE)

#- tabla infla OCDE -------------------------------------------------------------

#- solo Europa (q no sea Europa del Este) desde 2020
my_fecha <-  max(inflation$fecha)
my_fecha <-  "2023-02-01"

df <- inflation %>% 
  dplyr::filter(un.region.name %in% c("Europe")) %>% 
  dplyr::filter(!(region23 %in% c("Eastern Europe")))  %>% 
  dplyr::filter(fecha == my_fecha) %>% 
  #- digitos y % en inflacion
  mutate(inflacion.ch = pjpv.curso.R.2022::pjp_round_nice(inflacion), .after = inflacion) %>%
  mutate(inflacion.ch = paste0(inflacion.ch, "%")) %>% 
  mutate(inflacion.f =  as.factor(inflacion),  .after = inflacion) %>% 
  mutate(inflacion.f = forcats::fct_reorder(inflacion.f, inflacion))



my_title <- "Tasas de inflación interanual en Europa (febrero 2023)"
my_subtitle <- "Países europeos y <span style='color:#FED459'> España </span> "


#- de momento solo 1 tipo de inflacion
dfx <- df %>% filter(tipo_inf == "TOT")


p <- ggplot(dfx, aes(x = inflacion, y = pais)) +
  geom_col() +
  geom_text(aes(label = inflacion.ch, hjust = 1.2), size = 2.25, fontface = "bold") 
  

p
#- TODOS

library(tidytext) #- para la ff. reorder_within()

#- para mejorar bar plot: https://albert-rapp.de/posts/ggplot2-tips/16_bars_checklist/16_bars_checklist.html
p <- ggplot(df, aes(x = inflacion, y = reorder_within(pais, inflacion, tipo_inf))) +
   geom_col(fill = 'dodgerblue4') +
     facet_wrap(~ tipo_inf, scales = "free") +
     geom_text(aes(label = inflacion.ch, hjust = 1.0), size = 1.0, fontface = "bold",  color = 'white') +
     geom_text(mapping = aes(label = pais),
    hjust = -0.6,
    #vjust = 0.4,
    nudge_x = 0.25,
    color = 'red',
    fontface = 'bold',
    size = 1.0
  ) +
  labs(
    x = "Tasa de inflación", 
    y = element_blank(),
    title = my_title
  ) +
  theme_minimal(base_size = 14) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor.y = element_blank(),
  ) +
  geom_vline(xintercept = 0) +
  scale_x_continuous(breaks = NULL, expand = expansion(mult = c(0, 0.01))) +
  scale_y_discrete(breaks = NULL) +
  labs(x = element_blank()) +
  theme(panel.grid.major.x = element_blank(), panel.grid.minor.x = element_blank())
  
p
  
   p + theme(text = element_text(family = "Fira Sans Condensed"),
    plot.title = element_text(face = "bold", size = 24, hjust = 0.5),
    plot.title.position = "plot",
    plot.subtitle = element_markdown(lineheight = 1.1),
    plot.margin = margin(t = 10, l = 10, r= 10, b = 5),
    axis.title.x = element_blank(),
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.title.y = element_blank(),
    axis.text.y = element_text(),
    axis.ticks.y = element_blank(),
    panel.background = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "none",
    strip.background = element_blank(),
    strip.text = element_markdown()
  )


p

