#- estimar modelos para cada grupo
#- https://dplyr.tidyverse.org/articles/rowwise.html#per-row-summary-statistics-1

#- creo un list-colum df con nest
by_cyl <- mtcars %>% nest_by(cyl)


mods <- by_cyl %>% mutate(mod = list(lm(mpg ~ wt, data = data)))
mods <- mods %>% mutate(pred = list(predict(mod, data)))
mods %>% summarise(rmse = sqrt(mean((pred - data$mpg) ^ 2)))
mods %>% summarise(rsq = summary(mod)$r.squared)
mods %>% summarise(broom::glance(mod))


#- otra forma
#- estima el mismo modelo para todas las categorias de una variable (ha de ser factor)
library(tidyverse) 
library(broom)
#----- 
aa <- mtcars %>%
  mutate(cyl = factor(cyl), am = factor(am) ) %>%
  select(disp:wt) %>%
  map( ~ summary( lm(.x ~ cyl * am, data = mtcars) ) ) %>%
  map( ~ tidy(.x) )

#- si quieres grabar los resultados en un excel cada uno 

#aa <- aa %>% writexl::write_xlsx(., "mtcars_example.xlsx")

