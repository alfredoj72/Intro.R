#- quiero hacer un mapa con el crecimiento de la población en el periodo 2000-2020
library(tidyverse)
library(sf)

# datos ----
geo_muni <- readr::read_rds(here::here("datos", "geo_muni_2020_LAU2_canarias.rds"))
pob_2000_2020 <- readr::read_rds(here::here("datos", "ine_pob_mun_1996_2020.rds"))


#- crecimiento de la población en España 2000-2020
crec_esp <- pob_2000_2020 %>% 
  filter(year %in% c(2000, 2020)) %>% 
  filter(poblacion == "Total") %>% 
  select(year, values) %>% 
  group_by(year) %>% 
  summarise(habitantes = sum(values)) %>% 
  mutate(crec_abs = habitantes - lag(habitantes)) %>% 
  mutate(crec_percent = crec_abs /lag(habitantes)) %>% ungroup()

#- la pob. española creció un 17,16% en 2000-2020
media_crec_esp <-  crec_esp[[2,4]]*100
rm(crec_esp)

#- vamos a calcular el crecimiento de población a nivel MUNICIPAL (2000-2020)

#- filtro y selecciono lo que necesito
pob_muni <- pob_2000_2020 %>% 
  filter(year %in% c(2000, 2020)) %>% 
  filter(poblacion == "Total") %>% 
  select(-c(ine_muni.n.orig, ine_ccaa, ine_ccaa.n, capital_ccaa, poblacion)) %>%
  rename(habitantes = values) %>% 
  arrange(ine_muni)

#- paso a formato ancho (una columna para 2000 y otra para 2020)
pob_muni <- pob_muni %>% 
  pivot_wider(names_from = c("year"), values_from = c("habitantes")) 

#- calculo crecimiento de población a nivel municipal (2000-2020)
pob_muni <- pob_muni %>% 
  mutate(crec_2020_2000 = `2020`- `2000`) %>% 
  mutate(crec_porcentual = (`2020`- `2000`) / `2000` *100) %>% 
  arrange(desc(crec_porcentual)) 

#- creo mas variables: crec_porcentual.n, crec_porcentual.f
pob_muni <- pob_muni %>% 
  mutate(crec_porcentual.n = paste0(round(crec_porcentual, digits = 1), "%")) %>% 
  mutate(crec_porcentual.f = as_factor(case_when(
    crec_porcentual < 0 ~ "Negativo",
    between(crec_porcentual, 0, media_crec_esp) ~ "< media",
    crec_porcentual > media_crec_esp ~ "> media")))

#- reordeno los levels de crec_porcentual.f
pob_muni <- pob_muni %>% 
  mutate(crec_porcentual.f = fct_relevel(crec_porcentual.f, "Negativo", "< media"))

#-  mujeres --------------------------------------------------------------------

#- porcentaje mujeres en cada municipio
pob_muj <- pob_2000_2020 %>% 
  filter(year == 2020) %>% 
  filter(poblacion %in% c("Total", "Mujeres")) %>% 
  select(-c(ine_muni.n.orig, ine_ccaa, ine_ccaa.n, capital_ccaa)) %>%
  group_by(ine_muni, poblacion) %>% 
  summarise(habitantes = sum(values)) %>% 
  pivot_wider(names_from = poblacion, values_from = habitantes) %>% 
  mutate(percent_muj = Mujeres/Total *100) %>% ungroup()


#- fusiono crec pob muni y % de mujeres
df_ok <- left_join(pob_muni, pob_muj) %>% drop_na()

#- fusiono con geometrias
my_geo <- inner_join(geo_muni, df_ok)  

#- bivariate -------------------------------------------------------------------
library(biscale)


data = bi_class(
  my_geo,
  x = "crec_porcentual",
  y = "percent_muj",
  style = "quantile",
  dim = 3
)



main <- ggplot() +
  geom_sf(data = data, aes(fill = bi_class), 
    color = "white", size = 0.01, show.legend = FALSE) +
  bi_scale_fill(pal = "DkViolet", dim = 3,  na.value = 'grey90') +
  bi_theme() +
  labs(title = "Crecimiento población municipal 2000-2020 y % de mujeres") +
  theme(text = element_text(family = 'Leelawadee'),
    plot.title = element_text(size = 15, hjust = 0.5),
    plot.caption = element_text(size = 9, hjust = 0.5))


main


inset <-  ggplot() + 
  geom_sf(data = data, aes(fill = bi_class), 
           color = "white", size = 0.01, show.legend = FALSE) +
  bi_scale_fill(pal = "DkViolet", dim = 3, na.value = 'grey90') +
  bi_theme() +
   theme(plot.background = element_rect(fill = "transparent", color = NA),
         panel.background = element_rect(fill = "transparent", color = NA))


inset


map = main + annotation_custom(
    grob = ggplotGrob(inset), 
    #ymin = bbox_cont['ymin'],
    ymax = -3,
    xmin = -78.5,
    xmax = bbox_cont['xmax']
  )

legend = bi_legend(
  pal = "DkViolet",
  dim = 3,
  xlab = "Mayor\ncrecimiento\npoblación",
  ylab = "Mayor\nporcentaje\nmujeres",
  size = 7
) +
  theme(
    axis.title.y = element_text(margin = margin(r = -7)),
    axis.title.x = element_text(margin = margin(t = 10)),
    plot.background = element_rect(fill = "transparent", color = NA),
    panel.background = element_rect(fill = "transparent", color = NA)
  )


legend


# Open PNG device
png(filename = "./pruebas/day26.png",
    width = 20, height = 17, units = "cm", res = 300)
library(grid)

pushViewport(viewport(layout = grid.layout(nrow = 10, ncol = 14)))
# Arrange the plots
print(
  map,
  vp = grid::viewport(
    layout.pos.row = 1:10,
    layout.pos.col = 3:14,
    width = unit(14, "cm"),
    height = unit(14, "cm"))
)
print(
  legend,
  vp = grid::viewport(
    layout.pos.row = 1:2,
    layout.pos.col = 1:4,
    width = unit(7, "cm"),
    height = unit(7, "cm"),
    angle = 315)
)
dev.off()

#----- LORENA ------------------------------------------------------------------
#- script original de Lorena
#- bivariate map de Lorena: https://twitter.com/loreabad6/status/1464346174278799364
library(tidyverse)
library(readxl)
library(sf)
library(biscale)
library(grid)
library(rnaturalearth)
extrafont::loadfonts(device = "win")

## For bbox 
ec = ne_countries(scale = "small",
                  country = "Ecuador",
                  returnclass = "sf")

bbox_gal = c(
  xmin = -93.22,
  xmax = -87.638,
  ymin = -1.58,
  ymax = 1.77
) %>% st_bbox()

bbox_cont = ec %>% 
  st_cast("POLYGON") %>% 
  mutate(area = st_area(geometry)) %>% 
  top_n(1) %>% 
  st_buffer(10000) %>% 
  st_bbox()

popdens = read_xlsx(
  "data/inec/CPV2010/2_Densidad_Pobla_Nac_Prov_Cant_Parr.XLSX",
  sheet = 1, skip = 8, 
) |> 
  select(
    code = `Código`,
    pop = `Población`,
    popdens = `Densidad Poblacional`,
    area = `Superficie de la parroquia (km2)`
  ) 

pob = read_xls(
  "data/inec/CPV2010/32_NBI_POBLA_PROV_CANT_PARRO_AREA.xls",
  sheet = 1, skip = 12
)
pob_clean = pob |>
  drop_na(`Codigo de parroquia`) |>
  filter(Canton != "Total", `Codigo de parroquia` != "Total") |>
  select(canton = Canton, parroquia = `Codigo de parroquia`, poorperc = `...9`) |>
  distinct() |>
  mutate(
    parroquia = str_replace(str_to_lower(parroquia), " \\s*\\([^\\)]+\\)", ""),
    canton = str_to_lower(canton)
  )

par = read_sf("data/humdata/ecu_adm_inec_20190724_shp/ecu_admbnda_adm3_inec_20190724.shp")

datasf = par |> 
  select(parroquia = ADM3_ES, parcode = ADM3_PCODE, canton = ADM2_ES) |> 
  mutate(parcode = str_remove(parcode, "EC")) |> 
  mutate(
    parroquia = str_replace(str_to_lower(parroquia), " \\s*\\([^\\)]+\\)", ""),
    canton = str_to_lower(canton)
  ) |> 
  left_join(popdens, by = c("parcode" = "code")) |> 
  left_join(pob_clean) |> 
  drop_na(pop) |> 
  mutate(poorperc = as.numeric(poorperc)) |> 
  st_as_sf()

data = bi_class(
  datasf,
  x = "popdens",
  y = "poorperc",
  style = "quantile",
  dim = 3
)

main = ggplot() +
  geom_sf(
    data = data,
    aes(fill = bi_class), 
    color = "white", size = 0.01,
    show.legend = FALSE
  ) +
  bi_scale_fill(
    pal = "DkViolet",
    dim = 3,
    na.value = 'grey90') +
  bi_theme() +
  coord_sf(
    xlim = c(bbox_cont["xmin"], bbox_cont["xmax"]),
    ylim = c(bbox_cont["ymin"], bbox_cont["ymax"]),
  ) +
  labs(
    title = "Densidad poblacional y porcentaje de pobreza por parroquia",
    caption = "#30DayMapChallenge | Day 26: Choropleth | Data: INEC - Censo de Población y Vivienda 2010 | Created by @loreabad6"
  ) +
  theme(
    text = element_text(family = 'Leelawadee'),
    plot.title = element_text(size = 15, hjust = 0.5),
    plot.caption = element_text(size = 9, hjust = 0.5)
  )

inset = ggplot() +
  geom_sf(
    data = data,
    aes(fill = bi_class), 
    color = "white", size = 0.01,
    show.legend = FALSE
  ) +
  bi_scale_fill(
    pal = "DkViolet",
    dim = 3,
    na.value = 'grey90') +
  bi_theme() +
  coord_sf(
    xlim = c(bbox_gal["xmin"], bbox_gal["xmax"]),
    ylim = c(bbox_gal["ymin"], bbox_gal["ymax"]),
  ) +
  theme(
    plot.background = element_rect(fill = "transparent", color = NA),
    panel.background = element_rect(fill = "transparent", color = NA)
  )

map = main +
  annotation_custom(
    grob = ggplotGrob(inset), 
    ymin = bbox_cont['ymin'],
    ymax = -3,
    xmin = -78.5,
    xmax = bbox_cont['xmax']
  )

legend = bi_legend(
  pal = "DkViolet",
  dim = 3,
  xlab = "Mayor\ndensidad\npoblacional",
  ylab = "Mayor\nporcentaje\nprobreza",
  size = 7
) +
  theme(
    axis.title.y = element_text(margin = margin(r = -7)),
    axis.title.x = element_text(margin = margin(t = 10)),
    plot.background = element_rect(fill = "transparent", color = NA),
    panel.background = element_rect(fill = "transparent", color = NA)
  )

# Open PNG device
png(filename = "maps/day26.png",
    width = 20, height = 17, units = "cm", res = 300)
pushViewport(viewport(layout = grid.layout(nrow = 10, ncol = 14)))
# Arrange the plots
print(
  map,
  vp = grid::viewport(
    layout.pos.row = 1:10,
    layout.pos.col = 3:14,
    width = unit(14, "cm"),
    height = unit(14, "cm"))
)
print(
  legend,
  vp = grid::viewport(
    layout.pos.row = 1:2,
    layout.pos.col = 1:4,
    width = unit(7, "cm"),
    height = unit(7, "cm"),
    angle = 315)
)
dev.off()