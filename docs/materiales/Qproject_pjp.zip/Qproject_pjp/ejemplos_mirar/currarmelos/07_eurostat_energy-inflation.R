#- datos Eurostat
#- grupo Adeline, Lena y Luis: me mandaron estos links
#- datos de Eurostat sobre: Energy productivity
# -https://appsso.eurostat.ec.europa.eu/nui/show.do?dataset=nrg_ind_ep&lang=en  (Energy productivity)
# -https://appsso.eurostat.ec.europa.eu/nui/show.do?dataset=nrg_inf_epc&lang=en
# -https://appsso.eurostat.ec.europa.eu/nui/show.do?dataset=nrg_inf_epcrw&lang=en
# -https://appsso.eurostat.ec.europa.eu/nui/show.do?dataset=nrg_pc_202&lang=en

library(tidyverse)
library(eurostat)

aa <- search_eurostat("Energy", type = "all") #- busco datos relacionados con Energy
rm(aa)
my_table <- "nrg_ind_ep"      #- Energy productivity
# my_table <- "nrg_inf_epc"     #- Electricity production capacities by main fuel groups and operator
# my_table <- "nrg_inf_epcrw"     #- Electricity production capacities for renewables and wastes
# my_table <- "nrg_pc_202"     #- Gas prices for household consumers - bi-annual data (from 2007 onwards)
# my_table <- "nrg_bal_sd"     #- Gas prices for household consumers - bi-annual data (from 2007 onwards)


#-
label_eurostat_tables(my_table)        #- gives information about the table


#------------------ dowloading the selected  data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(d]f, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names <- names(df)
df <- label_eurostat(df, code = df_names, fix_duplicated = TRUE)


#- Veamos q hay en df ----------------------------------------------------
df_dicc <- pjpv.curso.R.2022::pjp_dicc(df)
df_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(df)

#- ver datos de Spain -----------------------
zz <- df %>% dplyr::filter(str_detect(geo_code, "^ES"))

#- me quedo la info q necesito
df <- df %>% select(geo_code, geo, time,  unit, unit_code, values)
str(df)
df <- df %>% mutate(time =  as.numeric(time))

#- tenemos códigos de la UE, pero mejor tener código "internacional" isoc2,
df <- df %>% mutate(iso2c =  eurostat::harmonize_country_code(geo_code), .after = geo_code)
zz <- df %>% filter(iso2c != geo_code)

#- si quisiéramos tener el código en 3 caracteres (iso3c)
zz <- df %>% mutate(iso3c = countrycode::countrycode(iso2c, origin = "iso2c", destination = "iso3c"), .after = iso2c)
zz <- zz %>% mutate(iso.name.fr = countrycode::countrycode(iso2c, origin = "iso2c", destination = "country.name.fr"), .after = iso3c)

#- tenemos 2 indicadores, asi que mejor lo pasamos a ancho
df_wide <- df %>%
  pivot_wider(names_from = c(unit_code, unit), values_from = values)

df_wide <- df %>% select(-unit) %>%
  pivot_wider(names_from = unit_code , values_from = values)


#- Adeline y compañia,seguramente TENDREIS q unir vuestras 4 tablas (x país y periodo)

#- por ejemplo la tabla: prc_hicp_manr
my_table <- "prc_hicp_manr"         #- HICP - monthly data (annual rate of change)
label_eurostat_tables(my_table)     #- gives information about the table


#------------------ dowloading the selected  data with get_eurostat()
df_2 <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(d]f, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names_2 <- names(df_2)
df_2 <- label_eurostat(df_2, code = df_names_2, fix_duplicated = TRUE)


#- Veamos q hay en df ----------------------------------------------------
df_dicc <- pjpv.curso.R.2022::pjp_dicc(df_2)
df_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(df_2)

#- selecciono lo q me interesa
names(df_2)
df_2 <- df_2 %>% select(geo, geo_code, coicop, coicop_code, time, values)

#- truquillo para ver q codigos de inflación tenemos
zz <- df_2 %>% count(coicop, coicop_code)

#- me interesan estos códigos
my_codes <- c("CP00", "CP0451", "NRG") #- general, electricidad y energía
df_2 <- df_2 %>% filter(coicop_code %in% my_codes)

#- nos queda arreglar la fecha
df_2 <- df_2 %>% mutate(fecha = lubridate::ym(time), .after = time)
df_2 <- df_2 %>% mutate(anyo = lubridate::year(fecha), .after = fecha)
df_2 <- df_2 %>% mutate(mes = lubridate::month(fecha), .after = anyo)

#- quitamos cosas
df_2 <- df_2 %>% select(-time, -fecha)

#- hagamos un gráfico de barras
zz <- df_2 %>% filter(anyo == 2022) %>% filter(mes == 11) %>% filter(coicop_code == "CP00")

theme_set(theme_grey())

p <- ggplot(zz, aes(y = geo, x = values)) + geom_col()
p
#- ya sabemos que para reordenar hay que pasar a factor etc...

#- para mejorar el barplot: https://albert-rapp.de/posts/ggplot2-tips/16_bars_checklist/16_bars_checklist.html
#- BUMP-plot: https://dominikkoch.github.io/Bump-Chart/


#- hagamos una coropleta ------------------- pero luego


#- si queremos fusionar df y df_2
#- pb xq en df_2 tenemos 3 variables my_codes <- c("CP00", "CP0451", "NRG")
#- y tenemos datos MENSUALES
df_2x <- df_2 %>% filter(coicop_code == "CP00") %>% filter(mes == 11)
str(df_2)

zz <- left_join(df, df_2x) #- NOOOO! xq fuionara tb x values y values != values

zz <- left_join(df, df_2x, by = c("geo_code" = "geo_code", "geo" = "geo", "time" = "anyo"))


#- gráfico de dispersión ---------------------
aa <- zz %>% filter(unit_code == "EUR_KGOE") %>%
  filter(time %in% c(2005, 2010, 2015, 2020)) %>%
  mutate(time = as.factor(time))

p <- ggplot(aa, aes(x = values.x, y = values.y, color = time)) +
  geom_point(size = 0.8) + geom_smooth(method = "lm", se = FALSE)
p

p <-  p + geom_text(aes(label = geo_code), nudge_x = 0.5)
p

p <- p + facet_wrap(vars(time))
p


#- dispersión con ggplotly
plotly::ggplotly(p)

#- como gganimate pero con plotly (frame = time): sale muy rápido y ...
pp <- aa %>% ggplot(aes(x = values.x, y = values.y, frame = time)) +
  geom_point(data = aa, aes(color = time), size = 0.3) +
  geom_text(aes(label = geo_code), nudge_x = 0.5) +
  geom_smooth(method = "lm", se = FALSE)
pp
plotly::ggplotly(pp)


#- coropleta ---------------------------
#- las coropletas se ven mejor con variables categóricas,
#- así que vamos a discretizar las v. que queramos graficar values.x y values.y
#- vamos a poner a cada país en un cuartil (logicamente lo calculamos año a año)
#- vamos a calcular los grupos/cuantiles con 2 funciones:
#- 1) con eurostat::cut_to_classes()
#- 2) con dplyr::ntile()  te pone un nombre para la categoría muy adecuado
#- Es posible que tus datos permitan categorizar para diferentes categorías. por ejemplo sex o edad etc....

df_ok <- aa %>% group_by(time) %>%
  #- fíjate que para discretizar hemos agrupado por "time"
  mutate(values.x.q  = cut_to_classes(values.x, n = 4, decimals = 1, style = "quantile")) %>%
  mutate(values.x.q.b = as.factor(ntile(values.x, n = 4))) %>%
  mutate(values.y.q  = cut_to_classes(values.y, n = 4, decimals = 1, style = "quantile")) %>%
  mutate(values.y.q.b = as.factor(ntile(values.y, n = 4))) %>%
  ungroup()


#- dowloading the geometries for European countries
geometrias <- get_eurostat_geospatial(resolution = "20", nuts_level = "0")
plot(geometrias, max.plot = 1)

#- merging the data with the geometries
mapdata <- inner_join(df_ok, geometrias, by = c("geo_code" = "id"))

#- selecciono lo q quiero graficar
mapdata_si <- mapdata %>%  filter(time == 2020)



p <- ggplot(mapdata_si) +
  geom_sf(aes(fill = values.x.q,  geometry = geometry), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") +
  labs(title = "Una variable sobre energia",
       subtitle = "(Adeline-Lena-Luis)",
       fill = "Mi variable (en cuartiles)",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))

p

#- Una mejora fácil es hacer un facet ---------------
#- ya he discretizado arriba
#- ahora con datos de inflación (values.y)

p <- mapdata %>%
  #filter(time %in% c(1980, 1990, 2000, 2010, 2017)) %>%
  ggplot() +
  geom_sf(aes(fill = values.y.q.b,  geometry = geometry), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") +
  labs(title = "Inflación mensual",
       subtitle = "(inflación = values.y, discretizado con ntile(): values.y.q.b)",
       fill = "Inflación en cuartiles",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))


p + facet_wrap(vars(time)) #-


#- vamos a recordar
#- tablas con gt ----------------
names(aa)
df_tabla <- aa %>%
  select(geo, iso2c, time, values.y, values.x) %>%
  rename(inflation = values.y) %>%
  rename(energy = values.x)

#- quito todo excepto
rm(list = setdiff(ls(), "df_tabla"))

#- !!!!! (para poner gráficos dentro de la tabla)
df_tabla <- df_tabla %>%
  group_by(iso2c) %>%
  mutate(inflation_evolution = list(inflation)) %>%
  filter(time == 2020) %>%
  ungroup()

str(df_tabla) #- la última columna es una lista


#- !!!!! (para poner banderas)
names(df_tabla)
df_tabla <- df_tabla %>%
  mutate(bandera = tolower(iso2c)) %>%
  mutate(bandera = glue::glue('https://hatscripts.github.io/circle-flags/flags/{bandera}.svg'))


#- !!!!! (para poner iconos)
#- vuelvo aponer cuartiles
df_tabla <- df_tabla %>% mutate(para_icono = as.factor(ntile(energy, n = 4)))


#- tablas con gt()
library(gt)

tt_ok <- df_tabla %>% gt::gt()
tt_ok

#- columna donde están los nombres de las filas
tt_ok <- df_tabla %>% gt(rowname_col = "geo")
tt_ok

#- titulo y subtitulo  (se puede usar markdown con md()  )
tt_ok <- tt_ok %>%
  tab_header(title = "Inflación y Energia",
             #- fíjate q si usas md() puedes formatear con sintáxis markdown
             subtitle = md("Un subtítulo **chulo**"))
tt_ok

#- notas al pie en el table footer ---------------------------------------------
#- con tab_source_note()
tt_ok <- tt_ok %>%
  tab_source_note(md("Fuente: datos de [Eurostat](https://ec.europa.eu/eurostat)")) %>%
  tab_source_note(md("Concretamente de: ..."))
tt_ok


#- cambio label de las columnas
tt_ok <- tt_ok %>% cols_label(inflation = "Tasa inflación (%)")
tt_ok

#- alineacion
tt_ok <- tt_ok %>% cols_align(align = "center")
tt_ok


#- más espacio a la columna de inflación
tt_ok <- tt_ok %>%
  cols_width(columns = c(inflation) ~ px(250))
tt_ok

#- con fmt_*() puedes dar formato a los valores de la tabla.
#- hay una familia de funciones fmt_*
tt_ok <- tt_ok %>%
  fmt_number(columns = c(inflation), #- everything()
             decimals = 1,
             sep_mark = ".",
             dec_mark = ",")
tt_ok


#- agrupando columnas con tab_spanner().
tt_ok <- tt_ok %>%
  tab_spanner(label = "Indicadores",
              columns = c(inflation, energy) )
tt_ok

#- al igual q en ggplot2 hay themes
tt_ok %>% gtExtras::gt_theme_nytimes()
tt_ok %>% gtExtras::gt_theme_guardian()

#- podemos poner gráficos ----------
tt_ok <- tt_ok %>% gtExtras::gt_plt_sparkline(inflation_evolution)
tt_ok

#- las banderas
tt_ok <- tt_ok %>% gtExtras::gt_img_rows(bandera, height = 25)
tt_ok

#- iconos
#- habíamos creado una vv. de "ranking" en realidad cuartiles
#- es la vv. "para_icono"

tt_ok <- tt_ok %>% gtExtras::gt_fa_rating(column = para_icono,
                                          max_rating = 4, color = "purple", icon = "star")

tt_ok



tt_ok <- tt_ok %>% opt_stylize(style = 2, color = "red")  #- red
tt_ok
