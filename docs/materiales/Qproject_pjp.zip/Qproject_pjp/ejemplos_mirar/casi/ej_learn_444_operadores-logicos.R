#- mas sobre operadores lógicos
#- las funciones isTRUE() e isFALSE() no están vectorizadas

#- en este hilo de twitter hacian una pregunta y Jenny se descolgo con esto:
#- https://github.com/r-lib/vctrs/issues/23


x <- c(TRUE, NA, FALSE)
is_true <- Vectorize(isTRUE)
is_false <- Vectorize(function(x) identical(x, FALSE))
is_not_true <- function(x) !is_true(x)
is_not_false <- function(x) !is_false(x)
is_true(x)
#> [1]  TRUE FALSE FALSE
is_false(x)
#> [1] FALSE FALSE  TRUE
is_not_true(x)
#> [1] FALSE  TRUE  TRUE
is_not_false(x)
#> [1]  TRUE  TRUE FALSE


#- algo parecido
x <- c(TRUE, NA, FALSE)
x %in% TRUE
#> [1]  TRUE FALSE FALSE
x %in% FALSE
#> [1] FALSE FALSE  TRUE
!x %in% TRUE
#> [1] FALSE  TRUE  TRUE
!x %in% FALSE
#> [1]  TRUE  TRUE FALSE