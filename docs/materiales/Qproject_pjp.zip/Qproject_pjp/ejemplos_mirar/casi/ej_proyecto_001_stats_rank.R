#- Igual hacer un ejemplo de ordenar: sort(), order(), rank()
#- https://datasciencetut.com/sorting-in-r/    (solo ve las f. de R-base)
#- https://towardsdatascience.com/r-rank-vs-order-753cc7665951 (tb R-base)
#- tengo que añadir las funciones de tidyverse
#- https://dplyr.tidyverse.org/reference/ranking.html
#- https://dplyr.tidyverse.org/articles/window-functions.html
