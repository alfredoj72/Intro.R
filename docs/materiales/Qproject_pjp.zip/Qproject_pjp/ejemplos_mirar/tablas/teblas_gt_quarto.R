
#- https://htmled.it/   (editor de html)

library(gt)
library(tidyverse)

aa <- c("Hola **tete**",
        "Hola
        pepe",
        "### This is Markdown.




Markdown’s syntax is comprised entirely of
punctuation characters, which punctuation
characters have been carefully chosen so as
to look like what they mean... assuming
you’ve ever used email.",

"Hola  \n
real
",
"<p><span>Como estas </span></p>
<p><span>tete</span></p>")

df <- data.frame(md = aa,
                 md_eval = aa,
                 md_html = aa)
gt::gt(df) %>% gt::fmt_markdown(md_eval)


data.frame(A = "Text", B = html("<em>Text</em>")) %>% gt()


dplyr::tibble(A = "Text", B = "<em>Text</em>") %>%
  gt() %>%
  fmt_markdown(columns = vars(B))

