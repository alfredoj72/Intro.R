#- ej: un nuevo paquete con una tabla chula: https://github.com/agstn/dataxray
#devtools::install_github("glin/reactable")
#devtools::install_github("agstn/dataxray")

library(dataxray)
library(tidyverse)
diamonds %>% 
  make_xray() %>% 
  view_xray()


pjpv.curso.R.2022::ine_censos_historicos_capitales  %>% 
  make_xray() %>% 
  view_xray()
