#- un ejemplo de creación de tablas con gt
#- gt cookbook: https://themockup.blog/static/gt-cookbook.html#Conditional_formatting
#- advanced cookbook: https://themockup.blog/static/gt-cookbook-advanced.html
#- https://www.liamdbailey.com/post/making-beautiful-tables-with-gt/
#- https://aosmith16.github.io/spring-r-topics/slides/week04_gt_tables.html#1
#- https://aosmith16.github.io/spring-r-topics/slides/week05_gt_flair.html#1
#- https://github.com/rich-iannone/gt-workshop

library(tidyverse)
library(gt)
options(scipen = 999) #- para quitar la notación científica


#- cargamos datos para generar algunos resultados y mostrarlos en tablas
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/PIAAC_data_small.csv"
df <- read_csv(my_url)


#- 
#- tt_6 ------------------------------------------------------------------------
#- Calculamos la media, el mínimo, el máximo y la desviación típica de Wage_month
df <- df %>% 
  group_by(Country) %>% 
  summarise(W_medio  = mean(Wage_month, na.rm = TRUE) ,
            W_minimo = min(Wage_month, na.rm = TRUE)  ,
            W_maximo = max(Wage_month, na.rm = TRUE)  ,
            W_sd = sd(Wage_month, na.rm = TRUE) ) %>% 
  ungroup()

#- creamos una gt_table --------------------------------------------------------
tt_6 <- df %>% gt()
tt_6 <- gt::gt(df)
tt_6

#- mejor decirle q columna contiene los nombres de las filas
tt_6 <- df %>% gt(rowname_col = "Country")

tt_6


#- vamos a ir añadiendo elementos /tuneando la tabla

#- títulos ---------------------------------------------------------------------
#- con tab_header() 
tt_6 <- tt_6 %>% 
  tab_header(title = "Salario en 4 países",
             subtitle = md("*sixth round* of **PIACC**"))   

tt_6

#- notas al pie en el table footer ---------------------------------------------
#- con tab_source_note()
tt_6 <- tt_6 %>% 
  tab_source_note(md("Fuente: datos de [PIAAC](http://www.oecd.org/skills/piaac/)")) %>%
  tab_source_note(md("Obtenidos a partir del paquete RPIAAC"))
tt_6


#- nota al pie en los valores de la tabla
#- con tab_footnote() y cell_body() para seleccionar q celdas marcar
tt_6 <- tt_6 %>% 
  tab_footnote(footnote = "salario en libras", 
               location = cells_body(columns = W_medio, rows = 3)) %>% 
  tab_footnote(footnote = "Bufff!!!", 
               location = cells_body(columns = W_sd, rows = c(1,4))) 
tt_6


#- The cols_*() functions allow for modifications of entire columns ------------

#- podemos cambiar los labels/titulos de las columnas con cols_label()
tt_6 <- tt_6 %>% cols_label(W_maximo = "Max.", W_minimo = "Min.") 
tt_6  

#- se puede usar MD en los nombres, dentro de md()
tt_6 <- tt_6 %>% cols_label(W_medio = md("**W medio**"))
tt_6
  
#- alineación de las columnas
#- Cuidado!!: Cambiar los labels no cambian los nombres de las v./columnas
tt_6 <- tt_6 %>% cols_align(align = "center") %>% 
                 cols_align(align = "right", columns = c("W_medio"))
tt_6

#- las columnas se pueden mover
tt_6 <- tt_6 %>% cols_move(columns = c(W_minimo, W_maximo), after = c(W_sd))
tt_6


#- Puedes controlar la anchura de las columnas
#- con cols_width() en pixels (px()) o % of the current size (pct()) 
tt_6 <- tt_6 %>% 
  cols_width(columns = c(W_medio) ~ px(90)) 
  
tt_6  


#- se pueden combinar columnas
tt_6 <- tt_6 %>% 
  cols_merge(columns = c(W_minimo, W_maximo), pattern = "[{1} - {2}]")
tt_6

tt_6 <- tt_6 %>% cols_label(W_minimo = "Rango") 
tt_6  

#- con fmt_*() puedes dar formato a los valores de la tabla.
tt_6 <- tt_6 %>% 
  fmt_number(columns = c(W_medio, W_sd),
             decimals = 1, 
             sep_mark = ".", 
             dec_mark = ",")
tt_6

#- añadir filas de totales o medias o .... -------------------------------------
tt_6 <- tt_6 %>% 
  summary_rows(columns = (W_medio),
               fns = list(Media = ~ mean(., na.rm = TRUE)))

tt_6

#- agrupando columnas con tab_spanner(). 
tt_6 <- tt_6 %>% 
  tab_spanner(label = "Cols. agrupadas",
              columns = c(W_sd, W_minimo) )
tt_6


#- el"theme" de la tabla -------------------------------------------------------

tt_6 <- tt_6 %>% 
  opt_row_striping() %>% 
  opt_table_font(font = google_font("Fira Mono")) %>% 
  tab_options(column_labels.border.bottom.color = "purple",
              table_body.border.bottom.color = "green",
              table_body.hlines.color = "orange")
tt_6

tt_6 <- tt_6 %>% 
  opt_row_striping() %>% 
  opt_table_font(font = google_font("Fira Mono")) %>% 
  tab_options(column_labels.border.bottom.color = "black",
              table_body.border.bottom.color = "black",
              table_body.hlines.color = "white") %>% 
    opt_align_table_header(align = "left") # left align header

tt_6

#- guardando la tabla ----------------------------------------------------------
gtsave(tt_6, "./pruebas/tt_6.rtf")
gtsave(tt_6, "./pruebas/tt_6.html")

#- guardando la tabla como imagen (hay q instalar el pkg "webshot")
gtsave(tt_6, "./pruebas/tt_6.png")


#- añadiendo colores a celdas --------------------------------------------------
tt_6 <- tt_6 %>% 
         tab_style(style = cell_fill(color = "lightblue"),
                   locations = cells_body(columns = W_medio,
                                          rows = W_medio >= mean(W_medio)))  %>% 
         tab_style(style = cell_text(color = "red"),
            locations = cells_body(columns = W_medio,
                                   rows = W_medio >= mean(W_medio))) %>% 
         tab_style(style = cell_borders(color = "orange", weight = px(10)),
            locations = cells_body(columns = W_minimo,
                                   rows = W_minimo > 115))
tt_6  
  



#- añadiendo colores -----------------------------------------------------------

tt_6 <- tt_6 %>% 
  data_color(columns = c(W_medio),
     colors = scales::col_numeric(palette = "Greens", domain = NULL) ) %>% 
  data_color(columns = c(W_sd),
      colors = scales::col_numeric(palette = "Reds", domain = c(500, 1000))) %>% 
  data_color(columns = c(W_minimo),
      colors = scales::col_numeric(palette = c("yellow", "purple"), domain = c(109, 117)),
             alpha = .9)
tt_6
    


#- incluyendo imágenes de internete---------------------------------------------
urls_fotitos <- c("https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Pancrudo_%2CCervera_del_Ric%C3%B3n_.Teruel.jpg/266px-Pancrudo_%2CCervera_del_Ric%C3%B3n_.Teruel.jpg",
                 "https://images.pexels.com/photos/97082/weimaraner-puppy-dog-snout-97082.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
                 "https://images.pexels.com/photos/35629/bing-cherries-ripe-red-fruit.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500",
                 "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Nacho_Vegas_Fib.jpg/800px-Nacho_Vegas_Fib.jpg")

df_img <- cbind(df, urls_fotitos) #- #- añadimos columnas con ruta a la imagen

tt_img <- df_img %>% gt() #- creamos la tabla tt_img a partir del df df_img
tt_img

tt_img %>% 
  gt::text_transform(locations = cells_body(columns = c(urls_fotitos)), 
                     fn = function(x){gt::web_image(x, height = 30)})

#- incluyendo imagenes (locales) -----------------------------------------------
#- habría q usar local_image() si la imagen estuviese en local

img_locales <- c("./imagenes/f3.png", 
                 "./imagenes/f4.png", 
                 "./imagenes/f1.webp", 
                 "./imagenes/f2.webp")

df_img <- cbind(df, img_locales)  #- añadimos columnas con ruta a la imagen
tt_img <- df_img %>% gt() #- creamos la tabla tt_img a partir del df df_img


tt_img %>% 
  gt::text_transform(locations = cells_body(columns = c(img_locales)), 
                     fn = function(x){gt::local_image(x, height = 30)})




#- insertar columna con las imágenes de las banderas ---------------------------
library(countrycode)
library(glue)

df_flags <- df %>% #- fips
  mutate(iso2 = countrycode(sourcevar = Country, origin = "iso3c", destination = "iso2c", warn = FALSE)) %>% 
  mutate(iso2 = tolower(iso2)) %>% 
  mutate(flag_URL = glue::glue('https://hatscripts.github.io/circle-flags/flags/{iso2}.svg')) 

tt_flags <- df_flags %>% gt()


tt_flags %>% 
  gt::text_transform(locations = cells_body(columns = c(flag_URL)), 
                     fn = function(x){gt::web_image(x, height = 30)})


#- pkg gtExtras: ---------------------------------------------------------------
#- pkg para añadir extra features a las tablas gt: https://jthomasmock.github.io/gtExtras/
#- trabajaremos con un df sencillito
df_ok <- df_flags %>% select( Country, flag_URL, W_medio, W_maximo, iso2)

#- cambiamos 2 enlaces
df_ok$flag_URL[2] <- "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Pirate_Flag_of_Jack_Rackham.svg/1280px-Pirate_Flag_of_Jack_Rackham.svg.png"

df_ok$flag_URL[1] <- "https://cdn-icons.flaticon.com/png/128/5784/premium/5784725.png?token=exp=1637490192~hmac=292c1736fae1aa6a7e1e897b48035c48"

#- creamos la tabla
tt_ok <- df_ok %>% gt(rowname_col = c("Country")) 
tt_ok  

#- ponemos las banderas again (pero mas facil)
tt_ok <- tt_ok %>% gtExtras::gt_img_rows(flag_URL, height = 25)
tt_ok

#- un bar_plot con gtExtras::gt_plt_bar_pct()
tt_ok <- tt_ok %>% 
  gtExtras::gt_plt_bar_pct(column = W_maximo, scaled = FALSE, fill = "blue", background = "lightblue") %>%
  cols_align("center", contains("scale")) 

#- hay themes
tt_ok %>% gtExtras::gt_theme_nytimes() 
                 
tt_ok

#- gtExtras::gt_plt_dot()
tt_ok %>% 
  gtExtras::gt_plt_dot(column = W_medio, category_column = iso2,  max_value = 1993,
           palette = c("red", "pink", "purple", "blue")) %>% 
  gt::tab_header(title = "Salario medio y máximo por países")

