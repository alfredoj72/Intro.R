#- @thomas_mock: Saw a beautiful table at: https://www.bloomberg.com/graphics/2021-german-election-results/
#- https://twitter.com/thomas_mock/status/1442541043019390982
#- gist: Code: https://gist.github.com/jthomasmock/b6fd5d64842296de2d1ef9cad6769f2c

library(tidyverse)
#----------------------------------------------------

library(gt)
library(gtExtras)  #- remotes::install_github("jthomasmock/gtExtras")
library(dplyr)
library(htmltools)

# original source: https://www.bloomberg.com/graphics/2021-german-election-results/

party_df <- tibble(
  Party = c("SPD", "CDU/CSU", "Greens", "FDP", "AfD", "Left", "Other"),
  Seats = c(206, 196, 118, 92, 83, 39, 1),
  `% of 2nd Votes` = c(25.7, 24.1, 14.8, 11.5, 10.3, 4.9, 8.7)
)

minimal_table <- gt(party_df) %>% 
  gt_plt_dot(column = Seats, category_column = Party,  max_value = 379,
             palette = c("#ec323f", "black", "#63d64a", "#fff24e", "#4fabf7", "#e956ad", "grey")) %>% 
  gtExtras::gt_theme_nytimes() %>% 
  tab_header(title = "Results by Party in the Bundestag Election",
             subtitle = "Seats and votes are based on provisional official results.") %>% 
  cols_width(Party ~ px(368), 3 ~ px(30))

party_table <- gt(party_df) %>% 
  gt_plt_dot(column = Seats, category_column = Party,  max_value = 368,
             palette = c("#ec323f", "black", "#63d64a", "#fff24e", "#4fabf7", "#e956ad", "grey")) %>% 
  gtExtras::gt_theme_nytimes() %>% 
  tab_header(title = "Results by Party in the Bundestag Election",
             subtitle = "Seats and votes are based on provisional official results.") %>% 
  cols_width(Party ~ px(300), 3 ~ px(30)) %>% 
  tab_style(style = list(cell_text(color = "grey"),cell_borders(color = "white")),
            locations = cells_body(3)) %>% 
  tab_source_note(
    html(
      paste0(
        "With a total of 735 seats<br>",
        "<span style='color:#bfbfbf;'>Data as of: Sept 26, 2021, 11:09PM CDT</span>"
      )
    )
  ) %>% 
  tab_style(style = cell_borders("right", "lightgrey", "dashed"),
            cells_body(Party)) %>% 
  tab_style(style = cell_borders("top", "white"), cells_body(rows = 1)) %>% 
  tab_options(table.border.bottom.color = "white")

combo_table <- htmltools::div(
  party_table,
  htmltools::div(
    "368 seats for majority",
    style = paste0(
      htmltools::css(
        background= "white", font.size = px(11), width = px(60),
        font.family = "arial", display = "flex", text.align = "center",
        color = "#999", position = "fixed", top = "230px", left = "290px"
      )
    )
  )
) 

# to save as an img
#gtExtras::gtsave_extra(combo_table, "combo-table.png", vwidth = 450, vheight = 430)

