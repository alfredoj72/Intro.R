#- script para seguir las slides de importación de datos

#- slide nº 6 ------------------------------------------------------------------

#- cuanto iniciamos R se cargan automáticamente un grupo de paquetes (R-base)
print(.packages()) #- [🌶]imprimimos los nombres de los "currently attached packages"

#- en uno de esos paquetes hay un conjunto de datos llamado "iris"
iris          #- llamamos a "iris"
str(iris)     #- qué es iris?
find("iris")  #- [🌶] ¿donde estaba iris?

my_iris <- iris  #- "hacemos una copia" de iris
find("my_iris")  #- ¿donde está my_iris?

iris <- iris     #- ???
find("iris")     #- ¿donde está ahora iris?


#- slide nº 7 ------------------------------------------------------------------

#- en el pkg palmerpenguins hay 2 conjuntos de datos
library(palmerpenguins) #- install.packages("palmerpenguins")

#- ya podemos usar los datos de penguins xq hemos cargado (attach) el paquete en memoria de R
penguins
my_penguins <- penguins

#- quiero tb hablaros de la siguiente expresión
#- es importante acostumbrarse a ella [ 🌟 ]
palmerpenguins::penguins


#- slide nº 9 ------------------------------------------------------------------

#- Solución--
rm(list = ls()) #- antes vamos a limpiar el Global env.

la_direccion <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

rio::import(la_direccion)    #- ¿qué ha pasado???

iris <- rio::import(la_direccion)  #- y ahora ¿qué ha pasado?

#- Solución (extended)--
rm(list = ls()) #- antes vamos a limpiar el Global env.

la_direccion <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

iris_1 <-  rio::import(la_direccion)  #- como un data.frame

iris_2 <- rio::import(la_direccion, setclass = "tibble")  #- como tibble

iris_3 <- tibble::as_tibble(iris_1) #- convertimos iris_1 a tibble


#- slide nº 11 -----------------------------------------------------------------

#- Solución 1 --
rm(list = ls())  #- [🌶] antes vamos a limpiar el Global env.

my_iris <- iris

rio::export(my_iris, "my_iris.csv")             #- sin los nombres de los argumentos
rio::export(x = my_iris, file = "my_iris.csv")  #- CON los nombres de los argumentos
#- IMPORTANTE: ¿Donde hemos guardado my_iris? [ 🌟 ]

#- Solución 2 (Ahora tenemos que guardar my_iris en la subcarpeta "pruebas")

fs::dir_create("pruebas")   #- [🌶] creo el subdirectorio

rio::export(my_iris, "./pruebas/my_iris.csv")

#- Perfecto, pero es mejor construir la ruta utilizando el pkg "here". [ 🌟 ]
la_ruta <- here::here("pruebas", "my_iris.csv")

rio::export(my_iris, la_ruta)

rio::export(my_iris, here::here("pruebas", "my_iris.csv"))


#- slide nº 12 -----------------------------------------------------------------

#- Solución 1 --
rio::export(iris, here::here("pruebas", "iris.csv"))
rio::export(iris, here::here("pruebas", "iris.xlsx"))
rio::export(iris, here::here("pruebas", "iris.sav"))

#- Solución 2 --
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.csv"))
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.xlsx"))
rio::export(palmerpenguins::penguins, here::here("pruebas", "pinguinos.dta"))


#- Solución 1 (à la PRO)
my_vec <- c("iris.csv", "iris.xlsx", "iris.sav")

for (ii in my_vec) {
  print(ii)
  # ...
}


#- slide nº 14 -----------------------------------------------------------------

#- Solución 1--
rm(list = ls())

iris_1 <- rio::import(here::here("pruebas", "iris.csv"))

iris_2 <- rio::import(here::here("pruebas", "iris.xlsx"))

#- Solución 2-- (tendrás que hacerlo tú)


#- Slide nº 15  [🌶]  ----------------------------------------------------------

#- en esta url hay un fichero de datos en formato .csv
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

#- descargamos y guardamos los datos en nuestro PC
download.file(url = my_url,
              destfile = "./pruebas/iris_descargado.csv")

curl::curl_download(url = my_url,
                    destfile = here::here("pruebas", "iris_descargado.csv"))

#- importamos los datos en R
aa <- rio::import(my_url)


#- BONUS (slides nº 17 a 19) --------------------------------------------------------

#- Bonus 1: le añadimos un libro mas al archivo "./pruebas/iris.xlsx"

rio::export(iris, "./pruebas/iris.xlsx")  #- por si acaso lo hubiésemos borrado

rio::export(iris, "./pruebas/iris.xlsx", which = "iris_2")

rio::export(x = iris,
            file = here::here("pruebas", "iris.xlsx"),
            which = "iris_3")

#- Bonus 2: (!!) exportar 2 df's en un único archivo .xlsx

rio::export(x = list(iris = iris,
                     pinguinos = palmerpenguins::penguins),
            file = here::here("pruebas", "my_iris_pinguinos.xlsx"))


#- Bonus 3: (!!) importar una hoja/libro especifica de un archivo .xlsx

iris_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"))  #- solo importa el primer libro

pinguinos_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"),
                           sheet = 2)
pinguinos_2 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"),
                           sheet = "pinguinos")

#- Bonus 4: (!!!!) importamos todos los libros de un archivo `.xlsx`

library(readxl) #- necesitamos readxl::excel_sheet()

mys_sheets <- readxl::excel_sheets(here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- con base::lapply()
my_dfs_list <- lapply(mys_sheets,
                      readxl::read_excel,
                      path = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- con purrr::map()
my_dfs_list2 <- purrr::map(mys_sheets,
                           readxl::read_excel,
                           path = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Extrayendo un data.frame de una lista: con [[]]

my_iris <- my_dfs_list2[[1]]

#- Bonus 5: (!!!!!!) importamos todos archivos de datos de la carpeta pruebas
library(purrr)
my_carpeta <- here::here("pruebas")

lista_de_archivos <- list.files(my_carpeta)  #- Ok con base ...
lista_de_archivos <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"



#- slide nº 21 -----------------------------------------------------------------
#- vamos a limpiar el Rproject: vamos a borrar los archivos q hemos creado:

list.files("./pruebas")     #- listado de archivos en la carpeta "./pruebas"

file.remove("./pruebas/pinguinos.dta")   #- borramos un archivo

#- borramos todos los archivos de ./pruebas/
file.remove(file.path("./pruebas", list.files("./pruebas")))

#- borramos toda la carpeta con el pkg fs
fs::dir_delete("pruebas")


#- slide nº 24 -----------------------------------------------------------------
#- exportando daros a formato  .Rda o .Rdata
fs::dir_create("pruebas")   #- creo la carpeta "pruebas" (otra vez)

save(mtcars, iris,  file = here::here("pruebas", "mtcars_and_iris.RData"))

#- importando datos en .Rda
load(here::here("pruebas", "mtcars_and_iris.RData"))


#- slide nº 25 -----------------------------------------------------------------
#- exportando daros a formato  .rds
saveRDS(iris, here::here("pruebas", "iris_1.rds"))          #- con base-R

readr::write_rds(iris, here::here("pruebas", "iris_2.rds")) #- con pkg "readr"

rio::export(iris, here::here("pruebas", "iris_3.rds"))

#- importando daros en formato  .rds
my_iris_1 <- readRDS(here::here("pruebas", "iris_1.rds"))     #- con R-base

my_iris_2 <-readr::read_rds(here::here("pruebas", "iris_2.rds")) #- tidyverse

my_iris_3 <- rio::import(here::here("pruebas", "iris_3.rds"))    #- con rio



#- slide nº 27 -----------------------------------------------------------------
#- accediendo a la API de Eurostat

library(eurostat) # install.packages("eurostat")
df <- get_eurostat("cult_emp_sex", time_format = 'raw', keepFlags = T)       #- bajamos los datos de la tabla "cult_emp_sex": empleo cultural por genero"

#- Si quieres probar tu mismo a bajar datos de Eurostat
library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
aa <- search_eurostat("employment", type = "all")

#- elegimos una tabla de Eurostat
my_table <- "hlth_silc_17"   #- elegimos una tabla; por ejemplo "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
label_eurostat_tables(my_table) #- da información sobre la Base de datos q estas buscando

#-  descargamos los datos con get_eurostat()
df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   #- bajamos los datos de una tabla
df_l <- label_eurostat(df)        #- pone labels: mas legible, menos fácil de programar


#- slide nº 28 -----------------------------------------------------------------

library(quantmod)  #- install.packages("quantmod")
#- For stocks and shares, the yahoo source is used.

facebook  <- getSymbols(Symbols = 'F', src = 'yahoo', auto.assign = FALSE)
barChart(facebook)

#- For currencies and metals, the oanda source is used.
tc_euro_dolar <- getSymbols(Symbols = 'EUR/USD', src = 'oanda', auto.assign = FALSE)

#- For economics series, the FRED source is used.
Japan_GDP <- getSymbols(Symbols = 'JPNNGDP', src = 'FRED', auto.assign = FALSE)


#- slide nº 30 -----------------------------------------------------------------

#- Webscrapping (ejemplo 1): Pueblos más altos de Teruel
library(rvest)
library(tidyverse)

my_url <- "https://es.wikipedia.org/wiki/Anexo:Municipios_de_la_provincia_de_Teruel"
content <- read_html(my_url)

body_table <- content %>%
              html_nodes('body')  %>%
              html_nodes('table') %>%
              html_table(dec = ",")

#- solo hay una tabla
Teruel <- body_table[[1]]  #- estoy haciendo subsetting de una lista


#- arreglamos (un poco) la tabla

names(Teruel) <- c("Nombre", "Extension", "Poblacion",
                   "Densidad", "Comarca", "Partido_judicial", "Altitud")
library(stringr)
Teruel <- Teruel %>% map(str_trim) %>% as_tibble() #- quita caracteres al final

Teruel <- Teruel %>% mutate(Altitud = str_replace_all(Altitud,"[[:punct:]]", ""))

Teruel <- Teruel %>% mutate(Altitud = as.double(Altitud)) %>% arrange(desc(Altitud))


#- slide nº 31 -----------------------------------------------------------------
#- Webscrapping (ejemplo 2)
library(rvest)
library(tidyverse)
my_url <- "https://es.wikipedia.org/wiki/Pandemia_de_enfermedad_por_coronavirus_de_2020_en_Espa%C3%B1a"

content <- read_html(my_url)
body_table <- content %>%
              html_nodes('body')  %>%
              html_nodes('table') %>%
              html_table(dec = ",", fill = TRUE)

#- la página web tiene 9 tablas
tabla_7 <- body_table[[7]]
tabla_8 <- body_table[[8]]


#- slide nº 33 -----------------------------------------------------------------

#- Solución 1 (con rio) --
rm(list = ls())  #- antes vamos a limpiar el Global env.

my_url <- "https://www.ine.es/daco/daco42/codmun/codmun20/20codmun.xlsx"

my_ruta_guardar <- here::here("pruebas", "20codmun.xlsx")

download.file(my_url, my_ruta_guardar) #- lo guardo en disco

df_1 <- rio::import(my_ruta_guardar) #- q pb tenemos?



#- Solución 3 (con readxl) --
df_2 <- readxl::read_xlsx(my_url, skip = 1)  #- no funciona. solo lee del PC

my_ruta_guardar <- here::here("pruebas", "20codmun.xlsx")

df_2 <- readxl::read_xlsx(my_ruta_guardar, skip = 1)

#- slide nº 34 -----------------------------------------------------------------

#- Un poco más profesional -
#- script para bajar la relación de municipios INE a 1 de enero de 2021

url_descarga <- "https://www.ine.es/daco/daco42/codmun/diccionario21.xlsx"
nombre_fichero <- "diccionario21.xlsx"

#- Explanation: https://stackoverflow.com/questions/8945477/regular-expression-for-getting-everything-after-last-slash

#- script para bajar la relación de municipios INE a 1 de enero de 2021
url_descarga <- "https://www.ine.es/daco/daco42/codmun/diccionario21.xlsx"
nombre_fichero <- "diccionario21.xlsx"

#- obtengo el nombre del archivo
nombre_fichero <- stringr::str_extract(url_descarga, "([^\\/]+$)")

#- añado la fecha de descarga al nombre de archivo
extension <- stringr::str_extract(url_descarga, "([^\\.]+$)")
nombre <- stringr::str_remove(nombre_fichero, paste0(".",extension))
nombre_fichero <- paste0(nombre , "_", Sys.Date(), ".", extension)

#- lo guardo
my_ruta <- here::here("pruebas", nombre_fichero) #- ruta para guardar el fichero
curl::curl_download(url = url_descarga, destfile = my_ruta)


#- importo el fichero
df <- readxl::read_xlsx(path = my_ruta, skip = 1)

#- slide nº 35 -----------------------------------------------------------------
#- seguimos con el ejemplo

#- arreglo los datos
library(tidyverse)
df <- df %>%
     mutate(ine_muni = paste0(CPRO, CMUN)) %>%
     mutate(year = "2021") %>%          #- !! cómo lo guardaría?
     mutate(year = as.numeric(year)) %>%
     rename(ine_muni.n = NOMBRE) %>%
     rename(ine_prov = CPRO) %>%
     select(ine_muni, ine_muni.n, ine_prov, year)

str(df)


#- exporto el archivo(me lo guardo)
readr::write_csv(df, file = here::here("pruebas", "my_relacion_muni_2021.csv"))


#- slide nº 36 -----------------------------------------------------------------

#- Contamos el nº de muni x provincias
df_muni <- df %>%
           group_by(ine_prov) %>%
           summarise(numero_muni = n())

df_muni <- df %>% count(ine_prov)

#- Si quisiéramos saber el nombre de las provincias ... tendríamos que cargar un nuevo fichero con esa información:

#- pak::pak("perezp44/pjpv.curso.R.2022")
codigos_prov <- pjpv.curso.R.2022::ine_pob_mun_1996_2021 %>%
                select(ine_prov, ine_prov.n) %>%
                distinct()

#- fusiono los 2 ficheros (lo veremos!!)
df_ok <- left_join(df_muni, codigos_prov)


#- Borro la carpeta tmp para dejar el Rproject limpio
fs::dir_delete("pruebas")  #- [🌶] borro la carpeta pruebas


#- Extras -----------------------------------


#- Solución a la tarea 1 (pp.12) pero "à la medio-PRO" ------
my_ruta <- here::here("pruebas")
my_rutas <- paste0(my_ruta, "/iris.", c("csv", "xlsx", "sav"))

for (ii in 1:3) {
  print(my_rutas[ii])
  rio::export(iris, my_rutas[ii] )
}



#- Solución pp.14 tarea 2 -----

rm(list = ls())
ping_csv <- rio::import("./pruebas/pinguinos.csv")
ping_xlsx <- rio::import(here::here("pruebas", "pinguinos.xlsx"))
ping_dta <- rio::import(here::here("pruebas", "pinguinos.dta"))
