#- script para bajar la relacion de municipios a 1 de enero de 2021
library(tidyverse)

url_descarga <- "https://www.ine.es/daco/daco42/codmun/diccionario21.xlsx"
nombre_fichero <- "diccionario21.xlsx"

fs::dir_create("tmp") #- creo un directorio temporal
my_ruta <- here::here("tmp", nombre_fichero) #- aquí descargaré los datos


curl::curl_download(url = url_descarga, destfile = my_ruta)

df <- readxl::read_xlsx(path = my_ruta, skip = 1)
df <- df %>%
      mutate(ine_muni = paste0(CPRO, CMUN)) %>%
      mutate(year = "2021") %>%          #- !! cómo lo guardaría?
      mutate(year = as.numeric(year)) %>%
      rename(ine_muni.n = NOMBRE) %>%
      rename(ine_prov = CPRO) %>%
      select(ine_muni, ine_muni.n, ine_prov, year)
str(df)

df_muni <- df %>% group_by(ine_prov) %>%
                summarise(numero_muni = n())

df_muni <- df %>% count(ine_prov)


#readr::write_csv(df, file = "./datos/relacion_muni_2021.csv")

#- pak::pak("perezp44/pjpv.curso.R.2022")
codigos_prov <- pjpv.curso.R.2022::ine_pob_mun_1996_2021 %>%
  select(ine_prov, ine_prov.n) %>%
  distinct()
str(codigos_prov)

df_ok <- left_join(df_muni, codigos_prov) #- fusiono

#- guardo los datos ya trabajados
# readr::write_csv(df_ok, file = "./datos/relacion_muni_2021.csv")

fs::dir_delete("tmp")  #- borro el directorio temporal
