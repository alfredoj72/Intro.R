#- Simpsons paradox: https://en.wikipedia.org/wiki/Simpson%27s_paradox

#- cargo paquetes
library(tidyverse)


#- cojos datos de pingüinos y arreglo un poco 
df <- palmerpenguins::penguins %>% 
  dplyr::select(species, bill_depth_mm, body_mass_g) %>% 
  tidyr::drop_na()


#- primer gráfico
p <- ggplot(data = df, 
       mapping = aes(x = bill_depth_mm, y = body_mass_g, color = species)) +
     geom_point()
p 

#- segundo gráfico
p <- p + geom_smooth(method = "lm", se = FALSE) 

p


#- tercer gráfico
p + geom_smooth(method = "lm", se = FALSE, color = "black") 



#- ruta a foto pingüinos: https://upload.wikimedia.org/wikipedia/commons/a/a9/Ping%C3%BCinos.JPG?20090406212143
