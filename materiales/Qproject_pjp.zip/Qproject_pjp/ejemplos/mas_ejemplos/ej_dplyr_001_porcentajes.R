#- https://fosstodon.org/@smach/109699224831388670
#- ejemplo tonto para calcular porcentajes
library(tidyverse)
library(gapminder)

#- calculemos el % de población de cada continente (en 2007)

df <- gapminder
aa <- df %>% group_by(year, continent) %>%
        summarise(pob_continent = sum(pop, na.rm = TRUE)) %>% ungroup()

aa_2007 <- aa %>% filter(year == 2007)

#- OK, ¿Cómo calculamos los porcentajes?

#- 1) con dplyr
bb <- aa_2007 %>%
  mutate(pob_mundo = sum(pob_continent, na.rm = TRUE)) %>%
  mutate(pob_continent_percent = pob_continent/pob_mundo)


#- 2) con el pkg relper
# remotes::install_github("vbfelix/relper")
bb <- aa_2007 %>%
  mutate(pob_continent_percent = relper::as_perc(pob_continent, sum = TRUE))

#- otro ejemplo con el pkg relper
mtcars %>%
  count(vs,am) %>%
  mutate(perc = relper::as_perc(n, sum = TRUE))


#- 3) con el pkg janitor
bb <- aa_2007 %>% janitor::tabyl(pob_continent) #- buhhhh!!! no es para esto, es para tabular casos


mtcars %>% janitor::tabyl(vs)

mtcars %>% janitor::tabyl(vs, am)

mtcars %>% janitor::tabyl(vs, am) %>% janitor::adorn_percentages()


