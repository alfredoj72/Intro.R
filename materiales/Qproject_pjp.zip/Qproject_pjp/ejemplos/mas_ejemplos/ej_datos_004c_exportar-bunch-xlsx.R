#- vamos a ver como podríamos importar libros de un archivo Excel
#- No es fácil!!
#- Un post: https://kieranhealy.org/blog/archives/2023/03/25/reading-remote-data-files/  aunque uso map_dfr() que en purrr 1.0.0 ha quedado superseded: https://fosstodon.org/@johnmackintosh/109768966119899585
#- otro post de exporatar several df's to an excel file: https://cran.r-project.org/web/packages/tablexlsx/vignettes/aa-examples.html#export-a-list-of-several-data-frames-to-an-xlsx-file-several-data-frames-in-a-same-sheet

library(tidyverse)

#- Para ello, primero vamos a crear varios conjuntos de datos
#- primero creamos solo un fdf con assign(). Esto no es fácil-fácil
assign(paste0("iris_", "01"), iris)
rm("iris_01")

 #- ok, ahora vamos a crear 3 ficheros de datos con la misma estructura
 #- esto no es fácil-fácil
anyos <- c(2021:2023)
my_names <- vector()

 for (ii in 1:length(anyos)) {
   print(anyos[ii])
   my_names[ii] <- paste0("iris_", anyos[ii])
   assign(my_names[ii], iris)
 }

#- OK, tenemos 3 df's q queremos exportar a un archivo .xlsx
#- esto no es fácil-fácil
get("iris_2021")

fs::dir_create("./pruebas") #- creo la carpeta

#- exportamos el primer df
rio::export(x = iris_2021,
            file = here::here("pruebas", "iris.xlsx"),
            which = "iris_2021")
#- ahora el resto
for (ii in 2:length(my_names)) {
  my_name <- my_names[ii]
  my_df <- get(my_name)
  #rio::export(my_df, my_ruta)
  rio::export(x = my_df,
              file = here::here("pruebas", "iris.xlsx"),
              which = my_name)
}

rm(my_df)


#- OK, ya tenemos 1 archivo Excel con 3 libros q queremos importar
#- AQUI en realidad empezaría el ejercicio de importación

my_archivo <- here::here("pruebas", "iris.xlsx") #- ruta al archivo

library(readxl)
my_dfs_list.1 <- lapply(excel_sheets(my_archivo),
                      read_excel,
                      path = my_archivo)

my_dfs_list.2 <- purrr::map(excel_sheets(my_archivo),
                            read_excel,
                            path = my_archivo)



#- tanto con purrr() como con lapply() es easy, PERO hay que saber un poco sobre manipular listas
#- 2 posibilidades para combinarlas
tbl.0 <- my_dfs_list.2 %>% purrr::reduce(bind_rows)
tbl.0 <- bind_rows(my_dfs_list.2, .id = "id")

