#- 2021-04-26 pedro.j.perez@uv.es
#- poblacion EUROSTAT: demo_r_pjanaggr3. Population on 1 January by broad age group, sex and NUTS 3 region.
#- ahora si dejo los grupos de edad( de 5 años)
#- actualización de la tabla: 11.03.2021
library(tidyverse)
library(eurostat)

aa <- search_eurostat("Population", type = "all") #- busco datos relacionados con población (354  datasets)

#my_table <- "demo_r_d2jan"         #- "Population on 1 January by age, sex and NUTS 2 region"
my_table <- "demo_r_pjangrp3"         #- "Population on 1 January by age group, sex and NUTS 3 region"

#-
label_eurostat_tables(my_table)        #- gives information about the table


#------------------ dowloading the selected  data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(d]f, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names <- names(df)
df <- label_eurostat(df, code = df_names, fix_duplicated = TRUE)
df_aa <- pjpv.curso.R.2022::pjp_valores_unicos(df, nn = 400)
#- ver lo de Spain -----------------------
zz_esp <- df %>% dplyr::filter(str_detect(geo_code, "^ES"))

#- me quedo la info de genero y grupos de edad
df <- df %>% select(-c(values_code, sex_code, unit, unit_code, flags, time))
df <- df %>% rename(year = time_code) %>% rename(poblacion = values)
df <- df %>% select(geo_code, geo, year,  sex, age_code, poblacion, flags_code, age)
str(df)
#- armonizar country codes
df <- df %>% mutate(iso_2_code =  eurostat::harmonize_country_code(geo_code))
df <- df %>% mutate(year =  as.numeric(year))



#- quiero calcular la región mas envejecida; definida como el ratio de gente de + de 80

df_ok <- df %>%
  filter(age_code %in% c("Y_GE90", "TOTAL")) %>%    #- filtro 2 grupos de edad
  filter(sex == "Total") %>%                        #- pob total
  select(-c(flags_code, sex,  age)) %>%             #- quito variables
  pivot_wider(names_from = age_code, values_from = poblacion) %>%
  mutate(pob_vieja = (Y_GE90/TOTAL)*100)

#- dowloading the geometries for European countries
geometrias <- get_eurostat_geospatial(resolution = "20", nuts_level = "3")
plot(geometrias, max.plot = 1)


#- como las coropletas se (suelen) ven mejor con variables categóricas:
#- Las cloropetas suelen quedar mejor si discretizamos la variable a graficar
#- podriamos hacerlo con ntile() pero eurostat::cut_to_classes() te pone un nombre para la categoría muy adecuado
#- Categorisng the values with cut_to_classes()
#- Es posible que tus datos permitan categorizar para diferentes categoriís. por ejemplo sex o edad etc....



#-  merging the data with the geometries
names(geometrias)
mapdata <- inner_join(df_ok, geometrias, by = c("geo_code" = "id"))


#- categorizo la variable "pob_vieja" ------------------------------------------

mapdata <- mapdata %>% group_by(year) %>%     #- en el otro ejemplo se llamaba time
  mutate(cat_time  = cut_to_classes(pob_vieja, n = 8, decimals = 1, style = "quantile"), .after = pob_vieja) %>%
  mutate(cat_time.f = as.factor(ntile(pob_vieja, n = 8)), .after = pob_vieja) %>% ungroup()




#- selecciono lo q quiero graficar: 2017
mapdata_si <- mapdata %>%  filter(year == 2017)



#- he creado la paleta en: https://colorbrewer2.org/#type=diverging&scheme=BrBG&n=9
my_paleta <- c('#8c510a','#bf812d','#dfc27d','#f6e8c3','#f5f5f5','#c7eae5','#80cdc1','#35978f','#01665e') #- diverging
my_paleta <- c('#f7fcfd','#e5f5f9','#ccece6','#99d8c9','#66c2a4','#41ae76','#238b45','#006d2c','#00441b') #- secuencial

p1 <- ggplot(mapdata_si) +
  geom_sf(aes(fill = cat_time,  geometry = geometry), color = "#74696d", size = .1) +
  scale_fill_manual(values = my_paleta) +
  labs(title = "% de población mayor de 90 años (2017)",
       #subtitle = "(por cada 100.000 habitantes)",
       fill = "% mayor de 90",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12, 44), ylim = c(35, 67))

p2 <- ggplot(mapdata_si) +
  geom_sf(aes(fill = cat_time.f,  geometry = geometry), color = "#74696d", size = .1) +
  scale_fill_manual(values = my_paleta) +
  labs(title = "% de población mayor de 90 años (2017)",
       #subtitle = "(por cada 100.000 habitantes)",
       fill = "% mayor de 90",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12, 44), ylim = c(35, 67))

library(patchwork)
p1 + p2

#- Una mejora fácil es hacer un facet ---------------
#- fijate que cojo los datos de varios (4 años)
#- fijate q ahora uso cat_time.f

p <- mapdata %>%
  ggplot() +
  geom_sf(aes(fill = cat_time.f,  geometry = geometry), color = "black", size = .1) +
  scale_fill_manual(values = my_paleta) +
  labs(title = "% de población mayor de 90 años (2017)",
       #subtitle = "(por cada 100.000 habitantes)",
       fill = "% mayor de 90",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12, 44), ylim = c(35, 67))

p + facet_wrap(vars(year)) #-



#- gganimate -------------------------------------------------------------------
library(gganimate)
p + transition_manual(year) +
  labs(title = "Año: {current_frame}",
       caption = "Datos de Eurostat")



#- gif: guardamos el gganimate como un gif
gganimate::anim_save("./pruebas/my_gganimate.gif")


#- cargamos el gif
my_gif <- magick::image_read("./pruebas/my_gganimate.gif") #- leemos el gif

my_gif



print(my_gif)   #- el gif tiene 7 frames



#- leemos una imagen, el logo de R ---------------------------------------------
logo <- magick::image_read("https://jeroen.github.io/images/Rlogo.png") %>%
  magick::image_resize("480x266!")
#- logo <- "./imagenes/R-logo.png"

#- insertamos el logo de R en el gif
my_gif[c(3:4)] <- logo
my_gif


