#- tabla inflación OCDE --------------------------------------------------------

library(tidyverse)
library(gt)

#- Datos -----------------------------------------------------------------------
#- Inflación de la OCDE -
#- web: https://data.oecd.org/price/inflation-cpi.htm
url_inflation <- "https://stats.oecd.org/sdmx-json/data/DP_LIVE/.CPI.../OECD?contentType=csv&detail=code&separator=comma&csv-lang=en"
ruta_inflation <- "./pruebas/DP_LIVE_22032023113248591.csv"
# curl::curl_download(url_inflation, ruta_inflation)
# download.file(url_inflation, ruta_inflation)
inflation_orig <- readr::read_csv(ruta_inflation)
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inflation_orig)
inflation_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(inflation_orig)

#- data munging
inflation <- inflation_orig %>%
  dplyr::filter(FREQUENCY == "M") %>% 
  dplyr::filter(MEASURE == "AGRWTH") %>% 
  #dplyr::filter(SUBJECT %in% c("TOT", "ENRG")) %>%
  dplyr::mutate(fecha = lubridate::ym(TIME)) %>% 
  select(pais = LOCATION, fecha, inflacion = Value, tipo_inf = SUBJECT)

#inflation <- inflation %>% pivot_wider(names_from = subject, values_from = cpi)
#pivot_longer(cols = ENRG:TOT, names_to = "indicador", values_to = "inflacion") %>% 

#- incorporar region para filtrar grupos de países
zz <- countrycode::codelist %>% select(iso.name.en, region, region23, wb, fips, ioc, imf, iso2c, iso3c, ecb, eurostat, continent, eu28, un, un.region.name)
#zz <- countrycode::codelist %>% select(iso.name.en, region23, region, iso3c) 

inflation <- left_join(inflation, zz, by = join_by(pais == iso3c) ) # %>% distinct(pais, .keep_all = TRUE)

#- solo Europa (q no sea Europa del Este) --------------------------------------
df <- inflation %>% 
  dplyr::filter(un.region.name %in% c("Europe")) %>% 
  dplyr::filter(!(region23 %in% c("Eastern Europe"))) 

  # #- digitos y % en inflacion
  # mutate(inflacion.ch = pjpv.curso.R.2022::pjp_round_nice(inflacion), .after = inflacion) %>%
  # mutate(inflacion.ch = paste0(inflacion.ch, "%")) %>% 
  # mutate(inflacion.f =  as.factor(inflacion),  .after = inflacion) %>% 
  # mutate(inflacion.f = forcats::fct_reorder(inflacion.f, inflacion))

my_title <- "Tasas de inflación interanual en Europa (febrero 2023)"
my_subtitle <- "Países europeos y <span style='color:#3569a4'> España </span> "

#- paso a ancho ----------------------------------------------------------------
df <- df %>% 
  select(pais, iso.name.en, fecha, inflacion, tipo_inf) %>% 
  pivot_wider(names_from = tipo_inf, values_from = inflacion)

#- banderas --------------------------------------------------------------------
df <- df %>% #- fips
  mutate(iso2 = countrycode::countrycode(sourcevar = pais, origin = "iso3c", destination = "iso2c", warn = FALSE)) %>% 
  mutate(iso2 = tolower(iso2)) %>% 
  mutate(flag_URL = glue::glue('https://hatscripts.github.io/circle-flags/flags/{iso2}.svg')) 
  
#- selecciono fecha ------------------------------------------------------------
my_fecha <-  max(inflation$fecha)
my_fecha <-  "2023-02-01"

df <- df %>% dplyr::filter(fecha == my_fecha) 

#- ordeno de + a - la inf. total -----------------------------------------------
df <- df %>% select(1,2, flag_URL, 3, 6, everything()) %>% arrange(desc(TOT), ENRG) %>% select(-iso2)

df <- df %>% mutate(FOOD = FOOD/max(FOOD))

#- tabla infla OCDE ------------------------------------------------------------

#- con DT: https://rstudio.github.io/DT/
df_DT <- df %>% select(-flag_URL)
DT::datatable(df_DT)
DT::datatable(df_DT, filter = 'top', extensions = "Scroller")

#- con reactable: https://glin.github.io/reactable/index.html
library(reactable)
reactable::reactable(df_DT, pagination = FALSE, height = 850, 
                     filterable = TRUE, searchable = TRUE, highlight = TRUE, 
                     columns = list( variable = colDef(
     # sticky = "left",
      # Add a right border style to visually distinguish the sticky column
      style = list(borderRight = "1px solid #eee"),
      headerStyle = list(borderRight = "1px solid #eee")
    )),
  defaultColDef = colDef(minWidth = 50)
)                     



#- con gt: https://gt.rstudio.com/
#df <- df %>% mutate(across(where(is.numeric), \(x) round(x, digits = 2)))


tt_6 <- df %>%  
  gt(rowname_col = "pais") %>% 
  tab_header(title = my_title, subtitle = md(my_subtitle))  %>% 
  tab_source_note(md("Fuente: datos proveniente de la [OCDE](http://www.oecd.org/)")) %>%
  gtExtras::gt_theme_nytimes() %>%
  gtExtras::gt_img_rows(flag_URL, height = 25) %>% 
  gtExtras::gt_merge_stack(col2 = iso.name.en, col1 = pais) %>% 
  tab_footnote(footnote = "Tasa de inflación eliminando el efecto de la energía y los alimentos", 
               location = cells_column_labels(columns = TOT_FOODENRG)) %>% 
  cols_label(TOT = md("**Total**"), ENRG = "Energética", FOOD = "Alimentos", TOT_FOODENRG = "Total sin ..." )  %>% 
  cols_align(align = "center") %>% 
  cols_align(align = "left", columns = fecha) %>% 
  cols_width(columns = TOT ~ px(120)) %>% 
  fmt_percent(columns = c(TOT, ENRG, FOOD, TOT_FOODENRG), scale_values = FALSE) %>% 
  tab_style(style = cell_text(color = "#f97d64"),
            locations = cells_body(columns = TOT,
            rows = TOT >= mean(TOT))) %>% 
  tab_style(style = cell_text(color = "#f97d64"),
            locations = cells_body(columns = FOOD,
            rows = FOOD >= mean(FOOD))) %>% 
   tab_style(style = cell_text(color = "#f97d64"),
            locations = cells_body(columns = ENRG,
            rows = ENRG >= mean(ENRG))) %>% 
   tab_style(style = cell_text(color = "#3569a4"),
            locations = cells_body(rows = pais == "ESP")) %>% 
   data_color(columns = c(TOT_FOODENRG),
              colors = scales::col_numeric(palette = "Reds", domain = NULL)) 
   
#gtExtras::gt_plt_bar_pct(column = FOOD, scaled = TRUE, fill = "blue", background = "lightblue")


tt_6  


#- guardando la tabla ----------------------------------------------------------
#gtsave(tt_6, "./pruebas/tt_6.rtf")
#gtsave(tt_6, "./pruebas/tt_6.html")

#- guardando la tabla como imagen (hay q instalar el pkg "webshot")
#gtsave(tt_6, "./pruebas/tt_6.png")
