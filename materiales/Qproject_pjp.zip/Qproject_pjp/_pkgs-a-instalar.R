#- instalación de paquetes ---------------------------------

install.packages("pak")

mys_pkgs <- c("tidyverse", "curl", "eurostat", "here", "palmerpenguins", "quantmod", "rio", "gt", "DT", "gapminder")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("perezp44/pjpv.curso.R.2022")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("usethis", "janitor", "ggthemes", "gganimate", "sjPlot")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("sf", "rcartocolor", "rmapshaper", "gtExtras", "patchwork", "magick")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("kableExtra", "modelsummary", "rpivotTable", "widyr", "irlba", "tmap")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("GGally", "ggtext", "Financial-Times/ftplottools", "maps")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("summarytools", "glin/reactable", "agstn/dataxray", "naniar")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("DataExplorer", "corrr", "inspectdf", "explore", "stargazer", "apaTables")
pak::pkg_install(mys_pkgs)

mys_pkgs <- c("easystats", "plotly")
pak::pkg_install(mys_pkgs)



#- finalmente, si te instalas todos los paquetes, se instalarán 284 pkg's (q ocupan 842 MB)
pkgs <- pak::pkg_list()

#- normalmente tendrás 2 librerías
.libPaths()
#- en la primera tienes los pkgs de "R-base": "C:/Program Files/R/R-4.3.0/library"
#- en la segunda tienes los paquetes q se instala un usuario:  "C:/Users/Usuario/AppData/Local/R/win-library/4.3"


#- más cosas ---------------------------------------
# usethis::edit_rstudio_prefs()
# usethis::use_blank_slate()

# quarto install tool tinytext
# quarto install tinytex --update-path
# quarto install tool chromium
